package com.gameservice.sdk.smartpush.example.view;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import com.gameservice.sdk.smartpush.example.R;

/**
 * HeaderFragment
 * Description:通用的header
 */
public class HeaderFragment extends Fragment implements OnClickListener {
    private ImageButton mBtnLeft;
    private TextView mTVTitle;
    private ImageButton mBtnRight;
    private MorePopupWindow morePopupWindow;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.custom_header, null);
        morePopupWindow = new MorePopupWindow(getActivity());
        mBtnLeft = (ImageButton) v.findViewById(R.id.btn_custom_header_left);
        mBtnLeft.setOnClickListener(this);
        mBtnRight = (ImageButton) v.findViewById(R.id.btn_custom_header_right);
        mBtnRight.setOnClickListener(this);
        mTVTitle = (TextView) v.findViewById(R.id.tv_custom_header_center);
        return v;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_custom_header_left:
                getActivity().onBackPressed();
                break;
            case R.id.btn_custom_header_right:
                morePopupWindow.showAtLocation(getActivity().findViewById(R.id.btn_custom_header_right),
                        Gravity.TOP | Gravity.RIGHT, 10, 205);
        }
    }

    public void setCenterText(String s) {
        if (mTVTitle != null && s != null) {
            mTVTitle.setText(s);
        }
    }

    public void dimissWindow() {
        morePopupWindow.dismiss();
    }

    public void hideLeftView() {
        mBtnLeft.setVisibility(View.INVISIBLE);
    }

    public void hideRightView() {
        mBtnRight.setVisibility(View.INVISIBLE);
    }
}
