package com.gameservice.sdk.smartpush.example.view;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.PopupWindow;
import android.widget.TextView;
import com.gameservice.sdk.smartpush.example.R;

/**
 * MorePopupWindow
 * Description:更多列表
 */
public class MorePopupWindow extends PopupWindow implements View.OnClickListener {
    private View mMenuView;
    private TextView tvShowDeviceInfo;
    private TextView tvShowAbout;
    private TextView tvShowHelp;
    private Context mContext;

    public MorePopupWindow(Context context) {
        super(context);
        mContext = context;
        Activity activity = (Activity) context;
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mMenuView = inflater.inflate(R.layout.list_more, null);
        int h = activity.getWindowManager().getDefaultDisplay().getHeight();
        int w = activity.getWindowManager().getDefaultDisplay().getWidth();
        this.setContentView(mMenuView);
        this.setWidth(w / 2 + 50);
        this.setHeight(LayoutParams.WRAP_CONTENT);
        this.setFocusable(true);
        this.setAnimationStyle(R.style.mystyle);
        ColorDrawable dw = new ColorDrawable(0);
        this.setBackgroundDrawable(dw);
        mMenuView.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                int height = mMenuView.findViewById(R.id.popupwindow_more).getTop();
                int y = (int) event.getY();
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (y < height) {
                        dismiss();
                    }
                }
                return true;
            }
        });
        tvShowAbout = (TextView) mMenuView.findViewById(R.id.show_about);
        tvShowHelp = (TextView) mMenuView.findViewById(R.id.show_help);
        tvShowDeviceInfo = (TextView) mMenuView.findViewById(R.id.show_deviceinfo);
        tvShowAbout.setOnClickListener(this);
        tvShowHelp.setOnClickListener(this);
        tvShowDeviceInfo.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.show_deviceinfo:
                Intent intent = new Intent(mContext, DeviceInfoActivity.class);
                mContext.startActivity(intent);
                break;
            case R.id.show_about:
                Intent intent1 = new Intent(mContext, AboutActivity.class);
                mContext.startActivity(intent1);
                break;
            case R.id.show_help:
                Intent intent2 = new Intent(mContext, HelpActivity.class);
                mContext.startActivity(intent2);
                break;
        }
    }
}
