package com.gameservice.sdk.smartpush.example;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ScrollView;
import android.widget.TextView;
import com.gameservice.sdk.push.api.IMsgReceiver;
import com.gameservice.sdk.push.api.SmartPush;
import com.gameservice.sdk.push.api.SmartPushOpenUtils;

/**
 * PushActivity
 * Description: Push示例，展示了如何使用SmartPushSDK
 */
public class PushActivity extends Activity {
    private TextView mTvAppId;
    private TextView mTvChannel;
    private TextView mTvAppKey;
    private TextView mTvVersion;
    private TextView mTvDebugContent;
    private ScrollView mSvDebugContent;

    private final static int DEBUG_LINES_RESTRICTION = 40;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_push);
        // 绑定xml控件
        initView();
        // 向控件填充数据
        initData();
        // 开启Push服务
        startPushService();
        //这边serverId和serverName规则为开发者自定义，键值对形式
        SmartPush.recordServer("1001", "春暖花开");
        //这边channelId和channelName规则为开发者自定义，键值对形式，最好在进入Application的时候设置.
        SmartPush.recordChannel("1", "新游互联");
    }

    private void initView() {
        mTvAppId = (TextView) findViewById(R.id.tv_appid);
        mTvChannel = (TextView) findViewById(R.id.tv_channel);
        mTvAppKey = (TextView) findViewById(R.id.tv_appkey);
        mTvVersion = (TextView) findViewById(R.id.tv_version);
        mTvDebugContent = (TextView) findViewById(R.id.tv_debug_content);
        mSvDebugContent = (ScrollView) findViewById(R.id.sv_debug_content);
    }

    private void initData() {
        mTvAppId.setText("AppId:" + DemoHelper.loadAppId(this));
        mTvChannel.setText("Channel:" + DemoHelper.loadChannelId(this));
        mTvAppKey.setText("AppKey:" + DemoHelper.loadAppKey(this));
        mTvVersion.setText("Version:" + DemoHelper.getVersion(this));
        String deviceToken = SmartPushOpenUtils.loadDeviceToken(this);
        if (!TextUtils.isEmpty(deviceToken)) {
            appendMsg("local_token: " + deviceToken);
        }
    }

    private void appendMsg(String msg) {
        mTvDebugContent.append(msg + "\r\n");
    }


    private void startPushService() {
        // 注册消息接受者
        SmartPush.registerReceiver(new MessageReceiver());
        // 注册服务，并启动服务
        SmartPush.registerService(this);
    }



    private class MessageReceiver implements IMsgReceiver {
        @Override
        public void onMessage(String message) {
            // 处理透传消息 message是Json字符串，如"{"ID":"id1", "NAME":"http:\/\/www.baidu.com"}"
            android.util.Log.i("TGX", "message:" + message);
            if (!TextUtils.isEmpty(message) && null != mTvDebugContent) {
                clearDebugText();
                appendMsg(message);
                mSvDebugContent.fullScroll(ScrollView.FOCUS_DOWN);
            }
        }

        @Override
        public void onDebug(String debugInfo) {
            // SDK发出的debug信息，可不处理
            if (!TextUtils.isEmpty(debugInfo) && null != mTvDebugContent) {
                clearDebugText();
                appendMsg(debugInfo);
                mSvDebugContent.fullScroll(ScrollView.FOCUS_DOWN);
            }
        }

        @Override
        public void onDeviceToken(String deviceToken) {
            //SmartPushOpenUtils是 sdk提供本地化deviceToken的帮助类，开发者也可以自己实现本地化存储deviceToken
            SmartPushOpenUtils.saveDeviceToken(PushActivity.this, deviceToken);
            // 玩家id与设备绑定,“0917”为玩家id
            SmartPush.bindDevice(PushActivity.this, deviceToken, "0917");
            if (!TextUtils.isEmpty(deviceToken) && null != mTvDebugContent) {
                clearDebugText();
                mTvDebugContent.append("sdk_token :" + deviceToken + "\r\n");
                mSvDebugContent.fullScroll(ScrollView.FOCUS_DOWN);
            }
        }

        private void clearDebugText() {
            if (mTvDebugContent.getLineCount() > DEBUG_LINES_RESTRICTION) {
                mTvDebugContent.setText("");
            }
        }

    }

    @Override
    protected void onResume() {
        // 记录用户离开当前页面行为
        SmartPush.onActivityResume(this);
        super.onStart();
    }

    @Override
    protected void onPause() {
        // 记录用户返回当前页面行为
        SmartPush.onActivityPause(this);
        super.onPause();
    }
}
