package com.gameservice.sdk.smartpush.example;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.ScrollView;
import com.gameservice.sdk.push.api.IMsgReceiver;
import com.gameservice.sdk.push.api.SmartPush;
import com.gameservice.sdk.push.api.SmartPushOpenUtils;
import com.gameservice.sdk.smartpush.example.base.BaseActivity;
import com.gameservice.sdk.smartpush.example.data.PushInfo;
import com.gameservice.sdk.smartpush.example.view.PushInfoListAdapter;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * MainActivity
 * Description:推送demo的主页面,向开发者展示了如何使用sdk
 */
public class MainActivity extends BaseActivity {
    private ListView mLvPushInfo;
    private View mEmptyView;
    private ArrayList<PushInfo> mPushInfoArray;
    private PushInfoListAdapter mPushInfoAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 初始化组件
        init();
        // 开启Push服务
        startPushService();
        //这边serverId和serverName规则为开发者自定义，键值对形式
        SmartPush.recordServer("1001", "春暖花开");
        //这边channelId和channelName规则为开发者自定义，键值对形式，最好在进入Application的时候设置.
        SmartPush.recordChannel("1", "新游互联");
    }

    private void initHeader() {
        bindHeader(R.id.main_headfrg);
        mHeader.setCenterText(getString(R.string.app_name));
        mHeader.hideLeftView();
    }

    private void init() {
        initHeader();
        mLvPushInfo = (ListView) findViewById(R.id.lv_pushinfo_content);
        mEmptyView = findViewById(R.id.empty_view);
        mPushInfoArray = new ArrayList<PushInfo>();
        mPushInfoAdapter = new PushInfoListAdapter(getApplicationContext(), mPushInfoArray);
        mLvPushInfo.setAdapter(mPushInfoAdapter);
        mLvPushInfo.setEmptyView(mEmptyView);
    }

    private void startPushService() {
        // 注册消息接受者
        SmartPush.registerReceiver(new MessageReceiver());
        // 注册服务，并启动服务
        SmartPush.registerService(this);
    }


    private class MessageReceiver implements IMsgReceiver {
        @Override
        public void onMessage(String message) {
            // 处理透传消息 message是开发者在网站上填的消息内容
            android.util.Log.i("PUSH", "message:" + message);
        }

        @Override
        public void onDebug(String debugInfo) {
            // SDK发出的debug信息，开发者不需处理
            try {
                JSONObject jsonObject = new JSONObject(debugInfo);
                PushInfo pushInfo = new PushInfo(jsonObject);
                mPushInfoArray.add(pushInfo);
                mPushInfoAdapter.notifyDataSetChanged();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onDeviceToken(String deviceToken) {
            //SmartPushOpenUtils是 sdk提供本地化deviceToken的帮助类，开发者也可以自己实现本地化存储deviceToken
            SmartPushOpenUtils.saveDeviceToken(MainActivity.this, deviceToken);
            // 玩家id与设备绑定,“0917”为玩家id
            SmartPush.bindDevice(MainActivity.this, deviceToken, "0917");
        }
    }

    @Override
    protected void onResume() {
        // 记录用户离开当前页面行为
        SmartPush.onActivityResume(this);
        super.onStart();
    }

    @Override
    protected void onPause() {
        // 记录用户返回当前页面行为
        SmartPush.onActivityPause(this);
        super.onPause();
    }
}
