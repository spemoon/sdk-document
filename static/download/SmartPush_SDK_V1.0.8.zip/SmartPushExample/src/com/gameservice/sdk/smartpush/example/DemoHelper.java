package com.gameservice.sdk.smartpush.example;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;

/**
 * DemoHelper
 * Description:demo帮助工具
 */
public class DemoHelper {
    private static final String META_APPID = "NGDS_APPID";
    private static final String META_APPKEY = "NGDS_APPKEY";
    private static final String META_CHANNEL = "NGDS_CHANNEL";

    /**
     * 读取AppID
     *
     * @param ctx
     * @return
     */
    public static String loadAppId(Context ctx) {
        String appId = "";
        ApplicationInfo appInfo = null;
        try {
            appInfo = ctx.getPackageManager()
                .getApplicationInfo(ctx.getPackageName(),
                    PackageManager.GET_META_DATA);
            appId = appInfo.metaData.getInt(META_APPID) + "";
        } catch (Exception e) {
            e.printStackTrace();
        }
        return appId;
    }

    /**
     * 读取AppKey
     *
     * @param ctx
     * @return
     */
    public static String loadAppKey(Context ctx) {
        String appSecret = "";
        ApplicationInfo appInfo = null;
        try {
            appInfo = ctx.getPackageManager()
                .getApplicationInfo(ctx.getPackageName(),
                    PackageManager.GET_META_DATA);
            appSecret = appInfo.metaData.getString(META_APPKEY);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return appSecret;
    }

    /**
     * 读取渠道ID
     *
     * @param context
     * @return
     */
    public static String loadChannelId(Context context) {
        if (null == context) {
            Log.e("NGDSDemo", "context is null");
            return null;
        }
        String channelId = "";
        ApplicationInfo appInfo = null;
        try {
            appInfo = context.getPackageManager()
                .getApplicationInfo(context.getPackageName(),
                    PackageManager.GET_META_DATA);
            channelId = String.valueOf(appInfo.metaData.getInt(META_CHANNEL));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return channelId;
    }

    /**
     * 读取App版本号
     *
     * @param context
     * @return
     */
    public static String getVersion(Context context) {
        try {
            PackageInfo manager = context.getPackageManager().getPackageInfo(
                    context.getPackageName(), 0);
            return manager.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "Unknown";
        }
    }
}
