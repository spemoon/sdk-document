package com.gameservice.sdk.smartpush.example;

import android.app.Application;
import cn.ngds.module.collect.util.error.NGDSCrashHandler;
import com.gameservice.sdk.push.api.SmartPush;

/**
 * BaseApp
 * Description: 基础application，用于在初始化的时候做一些事情
 */
public class BaseApp extends Application {
    // 系统默认的UncaughtException处理类
    private Thread.UncaughtExceptionHandler mDefaultUncaughtExceptionHandler;

    @Override
    public void onCreate() {
        super.onCreate();
        initErrorHandler();
        // 设置debug模式，true为debug模式；debug模式下会打印sdk的Log，便于调试
        SmartPush.setDebugMode(true);
    }

    private void initErrorHandler() {
        // 设置该CrashHandler为程序的默认处理器，帮助我们收集错误信息以反馈用户更好体验
        mDefaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(
            new NGDSCrashHandler(this, mDefaultUncaughtExceptionHandler));
    }

}
