package com.gameservice.sdk.smartpush.example.base;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import com.gameservice.sdk.smartpush.example.view.HeaderFragment;

/**
 * BaseActivity
 * Description:包含了header的基础Activity类
 */
public abstract class BaseActivity extends FragmentActivity {
    protected HeaderFragment mHeader;

    protected void bindHeader(int headerId) {
        mHeader = (HeaderFragment) getSupportFragmentManager().findFragmentById(headerId);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onResume() {
        if (mHeader != null) {
            mHeader.dimissWindow();
        }
        super.onResume();
    }

    @Override
    protected void onPause() {
        if (mHeader != null) {
            mHeader.dimissWindow();
        }
        super.onPause();
    }
}
