package com.gameservice.sdk.smartpush.example.view;

import android.os.Bundle;
import android.widget.TextView;
import com.gameservice.sdk.push.api.SmartPushOpenUtils;
import com.gameservice.sdk.smartpush.example.R;
import com.gameservice.sdk.smartpush.example.base.BaseActivity;
import com.gameservice.sdk.smartpush.example.utils.DemoHelper;

/**
 * ShowTokenActivity
 * Description:展示设备信息的页面
 */
public class DeviceInfoActivity extends BaseActivity {
    private TextView mTvAppId;
    private TextView mTvAppKey;
    private TextView mTvVersion;

    private TextView mTvToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deviceinfo);
        // 初始化header
        initHeader();
        // 初始化view
        initView();
    }

    private void initHeader() {
        bindHeader(R.id.token_headfrg);
        mHeader.setCenterText(getString(R.string.device_info));
        mHeader.hideRightView();
    }

    private void initView() {
        mTvAppId = (TextView) findViewById(R.id.tv_appid);
        mTvAppKey = (TextView) findViewById(R.id.tv_appkey);
        mTvVersion = (TextView) findViewById(R.id.tv_version);

        mTvToken = (TextView) findViewById(R.id.tv_device_token);
        mTvAppId.setText("AppId:" + DemoHelper.loadAppId(this));
        mTvAppKey.setText("AppKey:" + DemoHelper.loadAppKey(this));
        mTvVersion.setText("Version:" + DemoHelper.getVersion(this));
        mTvToken.setText("DeviceToken:" + SmartPushOpenUtils.loadDeviceToken(this));
    }
}
