//
//  NGRootViewController.m
//  NGSDKDemo
//
//  Created by shichangone on 26/7/14.
//  Copyright (c) 2014年 ngds. All rights reserved.
//

#import "NGRootViewController.h"
#import "NGGameService.h"
#import "NGNotifications.h"
#import "NGPaymentController.h"

@interface NGRootViewController ()

@end

@implementation NGRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onUserLogin:) name:kNGLoginDidSuccessNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onUserSkipLogin:) name:kNGDidSkipLoginNotification object:nil];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    UITapGestureRecognizer* gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTap:)];
    [self.view addGestureRecognizer:gesture];
    
    [self refreshLoginButton];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)onTap:(id)sender {
    [self.view endEditing:YES];
}

- (void)refreshLoginButton {
    if ([NGGameService isLogin]) {
        [_button1 setTitle:@"注销" forState:UIControlStateNormal];
        [_button2 setTitle:@"注销" forState:UIControlStateNormal];
    } else {
        [_button1 setTitle:@"登录" forState:UIControlStateNormal];
        [_button2 setTitle:@"登录(允许跳过)" forState:UIControlStateNormal];
    }
}

#pragma mark 登录
- (IBAction)actionLogin:(id)sender {
    if ([NGGameService isLogin]) {
        [NGGameService logout];
        
        [self refreshLoginButton];
    } else {
        [NGGameService login];
    }
}

- (IBAction)actionLoginAllowSkip:(id)sender {
    if ([NGGameService isLogin]) {
        [NGGameService logout];
        
        [self refreshLoginButton];
    } else {
        [NGGameService loginWithAllowSkip];
    }
}

- (void)onUserLogin:(NSNotification*)n {
    [self refreshLoginButton];
    
    if ([NGGameService isLogin]) {
        NSString* userID = [NGGameService userID];
        NSString* accessToken = [NGGameService accessToken];
        
        //验证accessToken
        
    }
}

- (void)onUserSkipLogin:(NSNotification*)n {
    [self refreshLoginButton];
    
    NSLog(@"用户跳过登录");
}

- (IBAction)actionPayment:(id)sender {
    NGPaymentRequest* payment = [[NGPaymentRequest alloc] init];
    payment.appName = @"拳行天下";
    payment.subject = @"测试商品名称";
    payment.body = @"测试商品名称";
    payment.amount = [_textField.text intValue];
    payment.notifyURL = @"http://dev.api.gameservice.com:8000/test_pay/test";
    payment.appID = @"10200";
    payment.appUserID = @"123";
    payment.appOrderID = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    payment.appUserName = @"角色名";
    payment.channelID = 14;
    
#if USING_SERVER_PAYMENT
    //服务器签名, 为保证资金安全，建议所有开发者使用
    //    NSString* stringToSing = [payment stringToSign];
    //    NSString* signFromServer = ....  //客户端将stringToSing提交到开发者服务器，对stringToSing进行签名后返回客户端
    //    payment.sign = signFromServer;
#else
    //本地支付，存在安全隐患，不建议使用
    payment.usingLocalSigniture = YES;
#endif
    
    NGPaymentController* controller = [[NGPaymentController alloc] initWithPayment:payment];
    controller.paymentDelegate = self;
    [self presentViewController:controller animated:YES completion:nil];
}

- (void)paymentController:(NGPaymentController*)paymentController didSuccessWithResult:(NGPaymentResult*)result {
    NGPaymentRequest* request = paymentController.payment;
    NSString* orderID = result.orderID;
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
    UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:@"支付成功" message:@"" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
    [alertView show];
}

- (void)paymentDidCancel:(NGPaymentController*)paymentController {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)log {
    [NGGameService setLoginPlayerID:@"123456677"];
    [NGGameService logPaymentWithPlayerID:@"123" payAmount:100];
}

@end
