//
//  NGNotifications.h
//  NGSDK
//
//  Created by shichangone on 22/7/14.
//  Copyright (c) 2014年 NGDS. All rights reserved.
//

#ifndef NGSDK_NGNotifications_h
#define NGSDK_NGNotifications_h

/**
 *  登录成功后发送的通知
 */
#define kNGLoginDidSuccessNotification @"NGLoginDidSuccessNotification"

/**
 *  用户跳过登录页面
 */
#define kNGDidSkipLoginNotification @"NGDidSkipLoginNotification"

/**
 *  用户注销
 */
#define kNGUserDidLogoutNotification @"NGUserDidLogoutNotification"

#endif
