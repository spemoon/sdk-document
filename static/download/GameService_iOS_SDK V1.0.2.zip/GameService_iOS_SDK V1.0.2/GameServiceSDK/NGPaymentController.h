//
//  NGPaymentController.h
//  NGSDK
//
//  Created by shichangone on 5/6/14.
//
//

#import <UIKit/UIKit.h>

@interface NGPaymentRequest : NSObject

@property (nonatomic,strong ) NSString   * appName;//应用名称

@property (nonatomic, strong) NSString   * subject;//商品名
@property (nonatomic, strong) NSString   * body;//商品描述
@property (nonatomic        ) NSUInteger amount;//价格（最小单位为“分”）
@property (nonatomic, strong) NSString   * notifyURL;//服务器回调地址
@property (nonatomic, strong) NSString   * appUserName;//应用用户名
@property (nonatomic, strong) NSString   * appUserID;//应用用户ID
@property (nonatomic ,strong) NSString   * appOrderID;//应用订单号
@property (nonatomic, strong) NSString   * appID;//应用ID
@property (nonatomic        ) NSInteger  channelID;//渠道ID

@property (nonatomic, strong) NSString   * sign;//签名

- (NSString*)stringToSign;      //待签名的数据

- (NSDictionary*)toDictionary;

@end

@interface NGPaymentResult : NSObject

@property (nonatomic, strong) NSString* orderID;    //新游订单ID
@property (nonatomic) NSUInteger amount;            //订单金额
@property (nonatomic, strong) NSString* subject;

@end

@class NGPaymentController;
@protocol NGPaymentControllerDelegate <NSObject>

- (void)paymentController:(NGPaymentController*)paymentController didSuccessWithResult:(NGPaymentResult*)result;

- (void)paymentDidCancel:(NGPaymentController*)paymentController;

@end

@interface NGPaymentController : UINavigationController

@property (nonatomic, strong) NGPaymentRequest* payment;

@property (nonatomic, weak) id<NGPaymentControllerDelegate> paymentDelegate;

- (instancetype)initWithPayment:(NGPaymentRequest*)payment;

@end
