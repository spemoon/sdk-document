//
//  NGRootViewController.m
//  NGSDKDemo
//
//  Created by shichangone on 26/7/14.
//  Copyright (c) 2014年 ngds. All rights reserved.
//

#import "NGRootViewController.h"
#import "NGGameService.h"
#import "NGGameServiceDefines.h"

@interface NGRootViewController ()

@end

@implementation NGRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onUserLogin:) name:kNGLoginDidSuccessNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onUserSkipLogin:) name:kNGDidSkipLoginNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(actionLogout:) name:kNGUserDidLogoutNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(actionPaySuccess:) name:kNGPaymentDidSuccessNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(actionPayCanceled:) name:kNGPaymentCanceledNotification object:nil];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    UITapGestureRecognizer* gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTap:)];
    [self.view addGestureRecognizer:gesture];
    
    [self refreshLoginButton];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)onTap:(id)sender {
    [self.view endEditing:YES];
}

- (void)refreshLoginButton {
    if ([NGGameService isLogin]) {
        [_button1 setTitle:@"注销" forState:UIControlStateNormal];
        [_button2 setTitle:@"注销" forState:UIControlStateNormal];
    } else {
        [_button1 setTitle:@"登录" forState:UIControlStateNormal];
        [_button2 setTitle:@"登录(允许跳过)" forState:UIControlStateNormal];
    }
}

#pragma mark 登录
- (IBAction)actionLogin:(id)sender {
    if ([NGGameService isLogin]) {
        [NGGameService logout];
        
        [self refreshLoginButton];
    } else {
        [NGGameService login];
    }
}

- (IBAction)actionLoginAllowSkip:(id)sender {
    if ([NGGameService isLogin]) {
        [NGGameService logout];
        
        [self refreshLoginButton];
    } else {
        [NGGameService loginWithAllowSkip];
    }
}

- (void)onUserLogin:(NSNotification*)n {
    [self refreshLoginButton];
    
    if ([NGGameService isLogin]) {
        NSString* userID = [NGGameService userID];
        NSString* accessToken = [NGGameService accessToken];
        
        //验证accessToken
        
    }
}

- (void)onUserSkipLogin:(NSNotification*)n {
    [self refreshLoginButton];
    
    NSLog(@"用户跳过登录");
}

- (void)actionLogout:(NSNotification *)notification {
    [self alertMessage:@"用户注销"];
}

- (void)actionPaySuccess:(NSNotification *)notification {
    NGPaymentResult *result = notification.object;
    [self alertMessage:[NSString stringWithFormat:@"支付结果：\n支付id%@\n 支付金额%d分\n  商品名称%@", result.orderID, result.amount, result.subject]];
}

- (void)actionPayCanceled:(NSNotification *)notification {
    [self alertMessage:@"支付取消"];
}

- (IBAction)actionPayment:(id)sender {
    NGPaymentRequest* payment = [[NGPaymentRequest alloc] init];
    payment.appName = @"拳行天下";
    payment.subject = @"测试商品名称";
    payment.body = @"测试商品名称";
    payment.amount = [_textField.text intValue];
    payment.notifyURL = @"http://dev.api.gameservice.com:8000/test_pay/test";
    payment.appID = @"9";
    payment.appUserID = @"123";
    payment.appOrderID = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    payment.appUserName = @"角色名";
    payment.channelID = 14;
    
    payment.usingLocalSigniture = YES; //强烈建议不适用这个，用服务器签名
    
    [NGGameService pay:payment];
}


- (void)log {
    [NGGameService setLoginPlayerID:@"123456677"];
    [NGGameService logPaymentWithPlayerID:@"123" payAmount:100];
}

#pragma mark

- (void)alertMessage:(NSString *)message {
    message = !message || message.length == 0 ? @"" : message;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:message delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil];
    [alert show];
}
@end
