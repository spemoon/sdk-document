//
//  NGGameService.h
//  NGSDK
//
//  Created by shichangone on 11/6/14.
//  Copyright (c) 2014年 NGDS. All rights reserved.
//
//  SDK Version : 1.0.3

#import <Foundation/Foundation.h>
#import "NGGameServiceDefines.h"

@interface NGGameService : NSObject

/**
 *  设置appID和app secret，App启动后必须设置这两个值
 *
 *  @param appID     appID
 *  @param appSecret appSecret
 */
+ (void)setAppID:(NSString*)appID AppSecret:(NSString*)appSecret;

/**
 *  设置APP的URL scheme，用于支付宝支付回调,微博SSO登录等
 *
 *  @param appURLScheme 
 */
+ (void)setAppURLScheme:(NSString*)appURLScheme;

/**
 *  设置推送Token，用于APNS推送
 *
 *  @param pushToken 用于APNS推送的token
 */
+ (void)setPushToken:(NSData*)pushToken;

/**
 *  设置屏幕方向
 *
 *  @param orientation 屏幕方向，只能为横屏或竖屏,默认为横屏
 */
+ (void)setOrientation:(UIInterfaceOrientationMask)orientation;


/**
 *  处理支付宝等App回调
 *
 *  @param url UIApplicationDelegate的
 *
 *  @return 是否处理掉该URL
 */
+ (BOOL)handleOpenURL:(NSURL*)url;

/**
 *  设置渠道ID，未设置时默认为14
 *
 *  @param channelID 渠道ID
 */
+ (void)setChannelID:(NSInteger)channelID;

/**
 *  当前SDK版本号
 *
 *  @return SDK版本号
 */
+ (NSString*)version;

#pragma mark 账号相关
/**
 *  显示登录界面, 用户无法关闭界面
 */
+ (void)login;

/**
 *  显示登录界面，登录界面允许用户跳过
 */
+ (void)loginWithAllowSkip;

/**
 *  当前是否有账号登录
 *
 *  @return 当前是否有账号登录
 */
+ (BOOL)isLogin;

/**
 *  注销
 */
+ (void)logout;


#pragma mark 已登录用户信息

/**
 *  获取平台用户ID
 *
 *  @return
 */
+ (NSString*)userID;

/**
 *  获取平台用户昵称
 *
 *  @return
 */
+ (NSString*)nickName;

/**
 *  获取平台登录token
 *
 *  @return
 */
+ (NSString*)accessToken;


#pragma mark 数据统计相关

/**
 *  记录用户登录
 *
 *  @param playerID 当前登录的游戏玩家ID,
 */
+ (void)setLoginPlayerID:(NSString*)playerID;

/**
 *  玩家付款行为统计：
 *
 *  @param playerID  当前登录的游戏玩家ID
 *  @param payAmount 付款金额（单位为分）
 */
+ (void)logPaymentWithPlayerID:(NSString*)playerID payAmount:(NSUInteger)payAmount;


#pragma mark 支付

/**
 *  显示支付界面
 *
 *  @param payment 支付内容
 */
+ (void)pay:(NGPaymentRequest *)payment;

@end
