//
//  NGGameServiceDefines.h
//  NGSDK
//
//  Created by chisj on 14-8-26.
//  Copyright (c) 2014年 NGDS. All rights reserved.
//

#pragma mark 登录相关Key ***********************************

extern NSString *const kNGLoginDidSuccessNotification;  // 登录成功后发送的通知

extern NSString *const kNGDidSkipLoginNotification;     //跳过登录发出的通知

extern NSString *const kNGUserDidLogoutNotification;    //用户注销发出的通知


#pragma mark 支付相关Key ***********************************

extern NSString *const kNGPaymentDidSuccessNotification;//支付成功通知

extern NSString *const kNGPaymentCanceledNotification;  //取消支付通知


#pragma mark 支付信息类 ************************************

/**
 *  支付信息
 */
@interface NGPaymentRequest : NSObject

@property (nonatomic,strong ) NSString   *appName;      //应用名称
@property (nonatomic, strong) NSString   *subject;      //商品名
@property (nonatomic, strong) NSString   *body;         //商品描述
@property (nonatomic        ) NSUInteger amount;        //价格，单位：分
@property (nonatomic, strong) NSString   *notifyURL;    //服务器回调地址,不能为空。服务器回调接口的实现请参考服务端接口文档
@property (nonatomic, strong) NSString   *appUserName;  //应用当前登录用户名
@property (nonatomic, strong) NSString   *appUserID;    //应用当前登录用户ID
@property (nonatomic ,strong) NSString   *appOrderID;   //应用订单号
@property (nonatomic, strong) NSString   *appID;        //应用ID，在新游后台注册得到的iOS版本appid
@property (nonatomic        ) NSInteger  channelID;     //渠道ID (选填)
@property (nonatomic, strong) NSString   *sign;         //签名，如果使用服务签名，请把开发者服务端计算得到的签名填到这里，如果设置为使用本地签名，则不要填此值。
@property (nonatomic, assign) BOOL       usingLocalSigniture; //是否使用本地签名，使用服务器签名不填此值

/**
 *  待签名的数据，用于服务器签名时提交给开发者的服务器签名接口
 *  具体请参看服务端文档
 *
 *  @return 待签名数据，字符串
 */
- (NSString*)stringToSign;

@end


/**
 *  支付成功信息
 */
@interface NGPaymentResult : NSObject

@property (nonatomic, strong) NSString* orderID;        //新游订单ID
@property (nonatomic        ) NSUInteger amount;        //订单金额
@property (nonatomic, strong) NSString* subject;        //商品名

@end
