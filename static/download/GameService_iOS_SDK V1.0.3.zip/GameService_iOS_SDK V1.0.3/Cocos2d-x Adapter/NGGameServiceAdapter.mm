//
//  NGGameServiceAdapter.mm
//  SDKTestByChisj
//
//  Created by chisj on 14-8-19.
//
//

#include "NGGameServiceAdapter.h"
#include "NGGameService.h"

#pragma mark 通知回调类

@interface NGGameServiceCallBackHandler : NSObject {
    
}

+ (NGGameServiceCallBackHandler *)shareInstance;

@end

static NGGameServiceCallBackHandler *shareInstance;

@implementation NGGameServiceCallBackHandler

+ (void)initialize {
    if (self == [NGGameServiceCallBackHandler class]) {
        shareInstance = [[NGGameServiceCallBackHandler alloc] init];
        [[NSNotificationCenter defaultCenter] addObserver:shareInstance selector:@selector(onUserLogin:) name:kNGLoginDidSuccessNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:shareInstance selector:@selector(skipLogin:) name:kNGDidSkipLoginNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:shareInstance selector:@selector(actionLogout:) name:kNGUserDidLogoutNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:shareInstance selector:@selector(actionPaySuccess:) name:kNGPaymentDidSuccessNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:shareInstance selector:@selector(actionPayCanceled:) name:kNGPaymentCanceledNotification object:nil];
    }
}

+ (NGGameServiceCallBackHandler *)shareInstance {
    return shareInstance;
}

#pragma mark SDK结果处理

- (void)onUserLogin:(NSNotification*)n {
    if ([NGGameService isLogin]) {
        [self alertMessage:[NSString stringWithFormat:@"userid:%@ \n token:%@", [NGGameService userID], [NGGameService accessToken]]];
        NGGameServiceAdapter::instance()->loginSuccessHandler();
    }
}

- (void)skipLogin:(NSNotification *)notification {
    [self alertMessage:@"跳过登录"];
    NGGameServiceAdapter::instance()->skipLoginHander();
}

- (void)actionLogout:(NSNotification *)notification {
    [self alertMessage:@"用户注销"];
    NGGameServiceAdapter::instance()->logoutHandler();
}

- (void)actionPaySuccess:(NSNotification *)notification {
    NGPaymentResult *result = notification.object;
    [self alertMessage:[NSString stringWithFormat:@"支付结果：\n支付id%@\n 支付金额%d分\n  商品名称%@", result.orderID, result.amount, result.subject]];
    NGGameServiceAdapter::instance()->paySuccessHandler();
}

- (void)actionPayCanceled:(NSNotification *)notification {
    [self alertMessage:@"支付取消"];
    NGGameServiceAdapter::instance()->payCanceldHandler();
}

#pragma mark

- (void)alertMessage:(NSString *)message {
    message = !message || message.length == 0 ? @"" : message;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:message delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil];
    [alert show];
}

@end

#pragma mark 适配类

static NGGameServiceAdapter *m_Instance;

NGGameServiceAdapter * NGGameServiceAdapter::instance(){
    if (m_Instance == NULL){
        m_Instance = new NGGameServiceAdapter();
    }
    [NGGameServiceCallBackHandler shareInstance];
    
    return m_Instance;
}

void NGGameServiceAdapter::login() {
    [NGGameService loginWithAllowSkip];
}

void NGGameServiceAdapter::logout() {
    [NGGameService logout];
}

void NGGameServiceAdapter::pay() {
    NGPaymentRequest* payment = [[NGPaymentRequest alloc] init];
    payment.appName = @"拳行天下";
    payment.subject = @"测试商品名称";
    payment.body = @"测试商品名称";
    payment.amount = 100;
    payment.notifyURL = @"http://dev.api.gameservice.com:8000/test_pay/test";
    payment.appID = @"9";
    payment.appUserID = @"123";
    payment.appOrderID = [NSString stringWithFormat:@"%d", (int)[[NSDate date] timeIntervalSince1970]];
    payment.appUserName = @"角色名";
    payment.channelID = 14;
    
    payment.usingLocalSigniture = YES; //强烈建议不适用这个，用服务器签名
    
    [NGGameService pay:payment];
}

bool NGGameServiceAdapter::isLogin() {
    return [NGGameService isLogin];
}

void NGGameServiceAdapter::loginSuccessHandler() {
    #warning 登录结果处理（需要自定义）
}
void NGGameServiceAdapter::skipLoginHander() {
    #warning 跳过登录
}
void NGGameServiceAdapter::logoutHandler() {
    #warning 注销处理
}
void NGGameServiceAdapter::paySuccessHandler() {
    #warning 支付成功处理
}
void NGGameServiceAdapter::payCanceldHandler() {
    #warning 取消支付处理
}

