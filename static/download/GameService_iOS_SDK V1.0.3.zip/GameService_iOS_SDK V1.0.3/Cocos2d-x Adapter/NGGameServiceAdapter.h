//
//  NGGameServiceAdapter.h
//  SDKTestByChisj
//
//  Created by chisj on 14-8-19.
//
//


#ifndef NGGameServiceAdapter_H_
#define NGGameServiceAdapter_H_

class NGGameServiceAdapter {
public:
    /*获取该类单例*/
    static NGGameServiceAdapter* instance();
    void login();
    void logout();
    bool isLogin();
    void pay();
    
    void loginSuccessHandler();
    void skipLoginHander();
    void logoutHandler();
    void paySuccessHandler();
    void payCanceldHandler();
    
};

#endif
