package com.gameservice.sdk.sample.view.push;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import com.gameservice.sdk.GameService;
import com.gameservice.sdk.sample.base.SDKDemoConstants;
import com.gameservice.sdk.sample.view.base.BaseActivity;
import com.gameservice.sdk.sample.R;

/**
 * PushServiceActivity
 * Description: provide function of push service
 *
 * @author walker_lx
 */
public class PushServiceActivity extends BaseActivity implements View.OnClickListener, SDKDemoConstants {
    private TextView         mTvAppId;
    private TextView         mTvAppSecret;
    private TextView         mTvDebugContent;
    private Button           mBtnStartService;
    private Button           mBtnStopService;
    private Button           mBtnUserLogin;
    private Button           mBtnUserLogout;
    private MsgDebugReceiver mMsgDebugReceiver;
    private ScrollView       mSvDebugContent;
    public final static  String MSG_DEBUG_INTENT        = "msg_debug_intent";
    public final static  String MSG_DEBUG_KEY           = "msg_debug_key";
    private final static int    DEBUG_LINES_RESTRICTION = 40;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_push);
        initView();
        registerListener();
        initData();
        registerReceiver(mMsgDebugReceiver, new IntentFilter(MSG_DEBUG_INTENT));
    }


    @Override
    protected void onDestroy() {
        unregisterReceiver(mMsgDebugReceiver);
        super.onDestroy();
    }

    private void initView() {
        mTvAppId = (TextView) findViewById(R.id.tv_appkey);
        mTvAppSecret = (TextView) findViewById(R.id.tv_appsecret);
        mTvDebugContent = (TextView) findViewById(R.id.tv_debug_content);
        mBtnStartService = (Button) findViewById(R.id.btn_start_service);
        mBtnStopService = (Button) findViewById(R.id.btn_stop_service);
        mBtnUserLogin = (Button) findViewById(R.id.btn_player_login);
        mBtnUserLogout = (Button) findViewById(R.id.btn_player_logout);
        mSvDebugContent = (ScrollView) findViewById(R.id.sv_debug_content);
    }

    private void registerListener() {
        mBtnStartService.setOnClickListener(this);
        mBtnStopService.setOnClickListener(this);
        mBtnUserLogin.setOnClickListener(this);
        mBtnUserLogout.setOnClickListener(this);
    }

    private void initData() {
        mTvAppId.setText(getString(R.string.app_id, getString(com.tgx.push.sdk.R.string.sdk_appid)));
        mTvAppSecret.setText(getString(R.string.app_secret, getString(com.tgx.push.sdk.R.string.sdk_appkey)));
        mMsgDebugReceiver = new MsgDebugReceiver();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_start_service:
                startPushSdk();
                break;
            case R.id.btn_stop_service:
                stopPushSdk();
                break;
            case R.id.btn_player_login:
                GameService.onPlayerLogin(this, PLAYER_ID);
                break;
            case R.id.btn_player_logout:
                GameService.onPlayerLogout(this);
                break;

        }
    }

    /**
     * 停止推送服务
     */
    private void stopPushSdk() {
        GameService.stopPushService(this);
    }

    /**
     * 开始推送服务
     */
    private void startPushSdk() {
        GameService.registerMsgReceiver(PushMessageReceiver.class);
        GameService.setPushTags(getApplicationContext(), new String[]{"phote"}, null); //设置标签为可选项
        GameService.startPushService(this);
    }


    /**
     * 消息debug信息接收者
     */
    class MsgDebugReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String msg = intent.getStringExtra(MSG_DEBUG_KEY);
            if (!TextUtils.isEmpty(msg) && null != mTvDebugContent) {
                clearDebugText();
                mTvDebugContent.append(msg + "\r\n");
                mSvDebugContent.fullScroll(ScrollView.FOCUS_DOWN);
            }
        }
    }

    private void clearDebugText() {
        if (mTvDebugContent.getLineCount() > DEBUG_LINES_RESTRICTION) {
            mTvDebugContent.setText("");
        }
    }
}
