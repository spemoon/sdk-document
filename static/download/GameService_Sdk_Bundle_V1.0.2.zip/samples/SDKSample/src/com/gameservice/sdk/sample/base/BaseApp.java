package com.gameservice.sdk.sample.base;

import android.app.Application;
import com.gameservice.sdk.GameService;

/**
 * BaseApp
 * Description: 基础application，用于在初始化的时候做一些事情
 */
public class BaseApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        GameService.startPushService(this);
    }
}
