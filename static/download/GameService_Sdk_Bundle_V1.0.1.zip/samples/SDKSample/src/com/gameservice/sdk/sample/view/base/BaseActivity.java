package com.gameservice.sdk.sample.view.base;

import android.app.Activity;
import com.gameservice.sdk.GameService;

/**
 * BaseActivity
 * Description:基础activity，在onPause和onResume中实现统计功能
 */
public class BaseActivity extends Activity {
    @Override
    protected void onPause() {
        GameService.onPause(this);
        super.onPause();
    }


    @Override
    protected void onResume() {
        GameService.onResume(this);
        super.onResume();
    }
}
