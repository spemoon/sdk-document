package com.gameservice.sdk.smartpush.example.view;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import com.gameservice.sdk.smartpush.example.R;
import com.gameservice.sdk.smartpush.example.BaseApp;

/**
 * MorePopupWindow
 * Description:更多列表
 */
public class MorePopupWindow extends PopupWindow implements View.OnClickListener {
    private View mMenuView;
    private TextView tvLogin;
    private TextView tvShowDeviceInfo;
    private TextView tvShowAbout;
    private TextView tvShowHelp;
    private Context mContext;

    public MorePopupWindow(Context context) {
        super(context);
        mContext = context;
        Activity activity = (Activity) context;
        LayoutInflater inflater = (LayoutInflater) context
            .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mMenuView = inflater.inflate(R.layout.list_more, null);
        int h = activity.getWindowManager().getDefaultDisplay().getHeight();
        int w = activity.getWindowManager().getDefaultDisplay().getWidth();
        this.setContentView(mMenuView);
        this.setWidth(w / 2 + 50);
        this.setHeight(LayoutParams.WRAP_CONTENT);
        this.setFocusable(true);
        this.setAnimationStyle(R.style.mystyle);
        ColorDrawable dw = new ColorDrawable(0);
        this.setBackgroundDrawable(dw);
        mMenuView.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                int height = mMenuView.findViewById(R.id.popupwindow_more).getTop();
                int y = (int) event.getY();
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (y < height) {
                        dismiss();
                    }
                }
                return true;
            }
        });
        tvLogin = (TextView) mMenuView.findViewById(R.id.tv_login);
        tvShowAbout = (TextView) mMenuView.findViewById(R.id.show_about);
        tvShowHelp = (TextView) mMenuView.findViewById(R.id.show_help);
        tvShowDeviceInfo = (TextView) mMenuView.findViewById(R.id.show_deviceinfo);
        tvLogin.setOnClickListener(this);
        tvShowAbout.setOnClickListener(this);
        tvShowHelp.setOnClickListener(this);
        tvShowDeviceInfo.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_login:
                final EditText inputServer = new EditText(mContext);
                inputServer.setHint("请输入玩家id");
                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setTitle("玩家登录").setIcon(
                    R.drawable.ic_launcher).setView(inputServer).setNegativeButton(
                    android.R.string.cancel, null);
                builder.setPositiveButton(android.R.string.ok,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            String playerId = inputServer.getText().toString();
                            BaseApp.setPlayerId(playerId);
                        }
                    });
                builder.show();
                break;
            case R.id.show_deviceinfo:
                Intent intent = new Intent(mContext, DeviceInfoActivity.class);
                mContext.startActivity(intent);
                break;
            case R.id.show_about:
                Intent intent1 = new Intent(mContext, AboutActivity.class);
                mContext.startActivity(intent1);
                break;
            case R.id.show_help:
                Intent intent2 = new Intent(mContext, HelpActivity.class);
                mContext.startActivity(intent2);
                break;
        }
        if (isShowing()) {
            dismiss();
        }
    }
}
