package com.gameservice.sdk.smartpush.example.view;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import com.gameservice.sdk.smartpush.example.R;

/**
 * HeaderFragment
 * Description:通用的header
 */
public class HeaderFragment extends Fragment implements OnClickListener {
    private ImageButton mBtnLeft;
    private TextView mTVTitle;
    private ImageButton mBtnRight;
    private MorePopupWindow morePopupWindow;
    private HeaderLeftButtonListener mHeaderLeftButtonListener;
    private View viewHeader;

    public interface HeaderLeftButtonListener {
        public void onLeftButtonClicked();
    }


    public HeaderLeftButtonListener mDefaultHeaderLeftButtonListener =
        new HeaderLeftButtonListener() {
            @Override
            public void onLeftButtonClicked() {
                getActivity().onBackPressed();
            }
        };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        viewHeader = inflater.inflate(R.layout.custom_header, null);
        morePopupWindow = new MorePopupWindow(getActivity());
        mBtnLeft = (ImageButton) viewHeader.findViewById(R.id.btn_custom_header_left);
        mBtnLeft.setOnClickListener(this);
        mBtnRight = (ImageButton) viewHeader.findViewById(R.id.btn_custom_header_right);
        mBtnRight.setOnClickListener(this);
        mTVTitle = (TextView) viewHeader.findViewById(R.id.tv_custom_header_center);
        mHeaderLeftButtonListener = mDefaultHeaderLeftButtonListener;
        return viewHeader;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_custom_header_left:
                if (null != mHeaderLeftButtonListener) {
                    mHeaderLeftButtonListener.onLeftButtonClicked();
                }
                break;
            case R.id.btn_custom_header_right:
                morePopupWindow.showAsDropDown(mBtnRight);
        }
    }

    public void setCenterText(String s) {
        if (mTVTitle != null && s != null) {
            mTVTitle.setText(s);
        }
    }



    public void dimissWindow() {
        morePopupWindow.dismiss();
    }

    public void hideLeftView() {
        mBtnLeft.setVisibility(View.INVISIBLE);
    }

    public void hideRightView() {
        mBtnRight.setVisibility(View.INVISIBLE);
    }
}
