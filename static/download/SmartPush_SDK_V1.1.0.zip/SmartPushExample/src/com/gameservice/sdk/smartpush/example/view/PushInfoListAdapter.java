package com.gameservice.sdk.smartpush.example.view;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.gameservice.sdk.push.api.type.PushInfo;
import com.gameservice.sdk.smartpush.example.R;

import java.util.ArrayList;

public class PushInfoListAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<PushInfo> array;
    private int count;
    private LayoutInflater inflater;

    public PushInfoListAdapter(Context context, ArrayList<PushInfo> array) {
        this.context = context;
        this.array = array;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        count = array.size();
        return count;
    }

    @Override
    public Object getItem(int position) {
        return array.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.list_pushinfo_item, null);
            holder.title = (TextView) convertView.findViewById(R.id.pushinfo_title);
            holder.content = (TextView) convertView.findViewById(R.id.pushinfo_content);
            holder.type = (TextView) convertView.findViewById(R.id.pushinfo_type);
            holder.time = (TextView) convertView.findViewById(R.id.pushinfo_time);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.title.setText("标题：" + array.get(position).getTitle());
        holder.content.setText("内容：" + array.get(position).getContent());
        String typeName;
        switch (array.get(position).getType()) {
            case PushInfo.PUSH_TYPE_APP:
                typeName = "启动应用";
                break;
            case PushInfo.PUSH_TYPE_DOWNLOAD:
                typeName = "下载";
                break;
            case PushInfo.PUSH_TYPE_WEB:
                typeName = "打开网页";
                break;
            case PushInfo.PUSH_TYPE_ACTIVITY:
                typeName = "启动应用指定页面";
                break;
            case PushInfo.PUSH_TYPE_DELIVER:
                typeName = "透传消息";
                break;
            default:
                typeName = "未知";
                break;
        }
        holder.type.setText("推送类型：" + typeName);
        return convertView;
    }

    public final class ViewHolder {
        public TextView title;
        public TextView content;
        public TextView type;
        public TextView time;
    }
}
