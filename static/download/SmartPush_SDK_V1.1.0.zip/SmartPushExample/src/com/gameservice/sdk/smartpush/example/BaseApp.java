package com.gameservice.sdk.smartpush.example;

import android.app.Application;
import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;
import cn.ngds.module.collect.util.error.NGDSCrashHandler;
import com.gameservice.sdk.push.api.IMsgReceiver;
import com.gameservice.sdk.push.api.SmartPush;
import com.gameservice.sdk.push.api.SmartPushOpenUtils;
import com.gameservice.sdk.push.api.type.PushInfo;

/**
 * BaseApp
 * Description: 基础application，用于在初始化的时候做一些事情
 */
public class BaseApp extends Application {
    // 系统默认的UncaughtException处理类
    private Thread.UncaughtExceptionHandler mDefaultUncaughtExceptionHandler;
    // 玩家ID
    private static String sPlayerId;
    private static Context sAppContext;


    @Override
    public void onCreate() {
        super.onCreate();
        sAppContext = this;
        // 设置异常处理器
        initErrorHandler();

        // 设置debug模式，true为debug模式；debug模式下会打印sdk的Log，便于调试(默认为非debug模式)
        SmartPush.setDebugMode(true);

        // *** 开始使用推送服务 ***
        startPushService();

        // 这边serverId和serverName规则为开发者自定义，键值对形式
        SmartPush.recordServer("1001", "春暖花开");
        // 这边channelId和channelName规则为开发者自定义，键值对形式，最好在进入Application的时候设置.
        SmartPush.recordChannel("1", "新游互联");
    }

    private void initErrorHandler() {
        // 设置该CrashHandler为程序的默认处理器，帮助我们收集Demo在不同设备中可能的错误信息以反馈用户更好体验
        mDefaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(
            new NGDSCrashHandler(this, mDefaultUncaughtExceptionHandler));
    }

    private void startPushService() {
        // 注册消息接受者
        SmartPush.registerReceiver(new IMsgReceiver() {
            @Override
            public void onMessage(PushInfo pushInfo) {
                // 处理消息
                switch (pushInfo.getType()) {
                    case PushInfo.PUSH_TYPE_DELIVER:
                        // 收到透传消息，需要开发者自行处理;
                        Log.i("PUSH", "透传消息:" + pushInfo.getContent());
                        break;
                    case PushInfo.PUSH_TYPE_APP:
                        // 收到启动应用消息，已经在通知栏显示，开发者可以不用处理;
                        break;
                    case PushInfo.PUSH_TYPE_DOWNLOAD:
                        // 收到下载消息，已经在通知栏显示，开发者可以不用处理;
                        break;
                    case PushInfo.PUSH_TYPE_WEB:
                        // 收到打开网页消息，已经在通知栏显示，开发者可以不用处理;
                        break;
                    case PushInfo.PUSH_TYPE_ACTIVITY:
                        // 收到打开应用指定页面消息，已经在通知栏显示，开发者可以不用处理;
                        break;
                    default:
                        break;
                }
            }

            @Override
            public void onDeviceToken(String deviceToken) {
                // SmartPushOpenUtils是 sdk提供本地化deviceToken的帮助类，开发者也可以自己实现本地化存储deviceToken
                SmartPushOpenUtils.saveDeviceToken(BaseApp.this, deviceToken);
                if (!TextUtils.isEmpty(sPlayerId)) {
                    // 玩家已登录
                    // ***用于接收推送, 一定要调用该接口后才能接受推送
                    SmartPush.bindDevice(BaseApp.this, deviceToken, sPlayerId);
                } else {
                    // ***用于接收推送,一定要调用该接口后才能接受推送  用户id与设备绑定,"0"为默认没有任何玩家登录时的默认id
                    SmartPush.bindDevice(BaseApp.this, deviceToken, "0");
                }
            }
        });
        // 注册服务，并启动服务
        SmartPush.registerService(this);
    }

    public static void setPlayerId(String playerId) {
        if (null == sAppContext) {
            return;
        }
        if (TextUtils.isEmpty(playerId)) {
            // demo传值为空,假定用户登出行为
            playerId = "0";
            Toast
                .makeText(sAppContext, sAppContext.getString(R.string.on_logout, playerId),
                    Toast.LENGTH_SHORT).show();
        }
        sPlayerId = playerId;
        String deviceToken = SmartPushOpenUtils.loadDeviceToken(sAppContext);
        if (TextUtils.isEmpty(deviceToken)) {
            Toast.makeText(sAppContext, R.string.token_null_prompt, Toast.LENGTH_SHORT).show();
            return;
        }
        SmartPush.bindDevice(sAppContext, deviceToken, sPlayerId);
        Toast
            .makeText(sAppContext, sAppContext.getString(R.string.on_player_login_prompt, playerId),
                Toast.LENGTH_SHORT).show();

    }
}
