package com.gameservice.sdk.smartpush.example;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import com.gameservice.sdk.push.api.IMsgReceiver;
import com.gameservice.sdk.push.api.SmartPush;
import com.gameservice.sdk.push.api.type.PushInfo;
import com.gameservice.sdk.smartpush.example.view.BaseActivity;
import com.gameservice.sdk.smartpush.example.view.PushInfoListAdapter;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

/**
 * MainActivity
 * Description:推送demo的主页面,向开发者展示了如何使用sdk
 */
public class MainActivity extends BaseActivity {
    private ListView mLvPushInfo;
    private View mEmptyView;
    private ArrayList<PushInfo> mPushInfoArray;
    private PushInfoListAdapter mPushInfoAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 初始化组件
        init();
        // Demo接收显示列表调试用，开发者不需在此调用
        new Timer().schedule(
            new TimerTask() {
                @Override
                public void run() {
                    SmartPush.registerReceiver(new MessageReceiver());
                }
            }, 1000);
    }

    private void initHeader() {
        bindHeader(R.id.main_headfrg);
        mHeader.setCenterText(getString(R.string.app_name));
        mHeader.hideLeftView();
    }

    private void init() {
        initHeader();
        mLvPushInfo = (ListView) findViewById(R.id.lv_pushinfo_content);
        mEmptyView = findViewById(R.id.empty_view);
        mPushInfoArray = new ArrayList<PushInfo>();
        mPushInfoAdapter = new PushInfoListAdapter(getApplicationContext(), mPushInfoArray);
        mLvPushInfo.setAdapter(mPushInfoAdapter);
        mLvPushInfo.setEmptyView(mEmptyView);
    }

    private class MessageReceiver implements IMsgReceiver {
        @Override
        public void onMessage(PushInfo pushInfo) {
            // 处理消息，此处只是显示消息记录Demo使用；正常请参考BaseApp里面的处理
            mPushInfoArray.add(0, pushInfo);
            mPushInfoAdapter.notifyDataSetChanged();
        }

        @Override
        public void onDeviceToken(String deviceToken) {
            // 请参考BaseApp里面的处理
        }
    }

    @Override
    protected void onResume() {
        // 记录用户离开当前页面行为
        SmartPush.onActivityResume(this);
        super.onStart();
    }

    @Override
    protected void onPause() {
        // 记录用户返回当前页面行为
        SmartPush.onActivityPause(this);
        super.onPause();
    }
}
