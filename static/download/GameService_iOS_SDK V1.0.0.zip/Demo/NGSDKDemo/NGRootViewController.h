//
//  NGRootViewController.h
//  NGSDKDemo
//
//  Created by shichangone on 26/7/14.
//  Copyright (c) 2014年 ngds. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NGPaymentController.h"

@interface NGRootViewController : UIViewController <NGPaymentControllerDelegate>

@property (nonatomic,strong ) IBOutlet   UIButton * button1;
@property (nonatomic, strong) IBOutlet   UIButton * button2;
@property (nonatomic, assign) IBOutlet UITextField* textField;

- (IBAction)actionLogin:(id)sender;

- (IBAction)actionLoginAllowSkip:(id)sender;

- (IBAction)actionPayment:(id)sender;

@end
