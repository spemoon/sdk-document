package com.gameservice.sdk.sample.view.push;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;
import com.tgx.push.sdk.app.AbstractMsgReceiver;

/**
 * PushMessageReceiver
 * Description:推送信息接收者
 */
public class PushMessageReceiver extends AbstractMsgReceiver {
    private static final String TAG = "PushMessageReceiver";

    public PushMessageReceiver(Context ctx) {
        super(ctx);
    }

    @Override
    public void onImReceive(long fromUid, long toUid, String msg) {
        onHandleIm(fromUid, toUid, msg);
        String msgLog = new StringBuilder().append("msg From ").append(fromUid)
                .append(" To ").append(toUid).append(" content is ").append(msg).toString();
        Toast.makeText(getContext(), msgLog, Toast.LENGTH_LONG).show();
        debugMsgForDev("onImReceive:" + msgLog);
        Log.d(TAG, msgLog);
    }

    @Override
    public void onMessage(String s) {
        debugMsgForDev("onMessage:" + s);
        Log.d(TAG, "onReceiveMsg:" + s);
        Toast.makeText(getContext(), s, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onDebug(String message) {
        super.onDebug(message);
        debugMsgForDev("onDebug:" + message);
        Log.d(TAG, "onPushDebug:" + message);
    }

    private void debugMsgForDev(String message) {
        Intent intent = new Intent(PushServiceActivity.MSG_DEBUG_INTENT);
        intent.putExtra(PushServiceActivity.MSG_DEBUG_KEY, message);
        getContext().sendBroadcast(intent);
    }
}
