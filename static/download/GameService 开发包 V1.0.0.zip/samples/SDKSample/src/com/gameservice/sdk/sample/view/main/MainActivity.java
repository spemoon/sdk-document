package com.gameservice.sdk.sample.view.main;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import com.gameservice.sdk.GameService;
import com.gameservice.sdk.OAuthInfo;
import com.gameservice.sdk.OnLoginListener;
import com.gameservice.sdk.StatusCode;
import com.gameservice.sdk.sample.R;
import com.gameservice.sdk.sample.base.SDKDemoConstants;
import com.gameservice.sdk.sample.view.base.BaseActivity;

public class MainActivity extends BaseActivity implements View.OnClickListener, SDKDemoConstants {
    private static boolean isInit = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnPay).setOnClickListener(this);
        findViewById(R.id.btn_push_service).setOnClickListener(this);

        // 横屏，在调用页面接口前设置
        GameService.setScreenOrientation(GameService.SCREEN_ORIENTATION_LANDSCAPE);

        if (isInit) {
            isInit = false;
            doLogin();
        }
    }


    private void doLogin() {
        GameService.login(MainActivity.this, new OnLoginListener() {
            @Override
            public void finish(int code, OAuthInfo oAuthInfo) {
                String msg = "";
                switch (code) {
                    case StatusCode.FINISH:
                        msg = "token: " + oAuthInfo.getAccessToken();
                        break;
                    case StatusCode.CANCEL:
                        msg = "取消登陆";
                        break;
                    default:
                        break;
                }
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
                Log.d("OAuth: ", +code + ": " + msg);
            }
        });
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.btnPay:
                Intent intent = new Intent(this, com.gameservice.sdk.sample.view.main.TestPayActivity.class);
                startActivity(intent);
                break;

            case R.id.btn_push_service:
                Intent pushServiceIntent = new Intent(this, com.gameservice.sdk.sample.view.push.PushServiceActivity.class);
                startActivity(pushServiceIntent);
                break;
//            case R.id.btn_payment_upload:
//                GameService.onPay(this, PLAYER_ID, "200");
//                break;
            default:
                break;
        }
    }

}
