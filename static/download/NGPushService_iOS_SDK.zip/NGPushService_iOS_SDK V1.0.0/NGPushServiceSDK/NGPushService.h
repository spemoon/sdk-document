//
//  NGPushService.h
//  NGSDK
//  v 1.0.0
//
//  Created by chisj on 14-9-12.
//  Copyright (c) 2014年 NGDS. All rights reserved.
//

#import <Foundation/Foundation.h>

@class NGPaymentRecord, NGRegistRecord, NGLevelRecord, NGMissionRecord, NGConsumptionRecord, NGCoinRecord;

@interface NGPushService : NSObject

#pragma mark 平台初始化

/**
 *  设置appID和app secret，App启动后必须设置这两个值
 *
 *  @param appID     appID
 *  @param appSecret appSecret
 */
+ (void)setAppID:(NSString*)appID AppSecret:(NSString*)appSecret;

/**
 *  设置推送token
 *
 *  @param pushToken token数据
 */
+ (void)setPushToken:(NSData *)pushToken;

/**
 * 记录登录玩家id，在setPushToken之后调用。
 *  请务必设置playID，如果游戏不存在playerId，可设置"0"
 *
 *  @param playerID 当前登录的游戏玩家ID,
 */
+ (void)setLoginPlayerID:(NSString*)playerID;

/**
 *  设置渠道ID 默认可不设置
 *
 *  @param channelID 渠道id
 */
+ (void)setChannelID:(NSString *)channelID channelName:(NSString *)channelName;

/**
 *  当前SDK版本号
 *
 *  @return SDK版本号
 */
+ (NSString*)version;


#pragma mark 采集数据记录

/**
 *  统计支付
 *
 *  @param paymentRecord 支付信息
 */
+ (void)pay:(NGPaymentRecord *)paymentRecord;

/**
 *  统计进入某个等级，在玩家进入游戏或者升级之后调用
 *
 *  @param levelRecord 等级信息
 */
+ (void)reachLevel:(NGLevelRecord *)levelRecord;

/**
 *  统计离开某个等级，在玩家离开游戏或者升级之前调用
 *
 *  @param levelRecord 等级信息
 */
+ (void)leaveLevel:(NGLevelRecord *)levelRecord;

/**
 *  统计进入某个关卡
 *
 *  @param missionRecord 关卡信息
 */
+ (void)enterMission:(NGMissionRecord *)missionRecord;

/**
 *  统计离开某个关卡
 *
 *  @param missionRecord 关卡信息
 */
+ (void)leaveMission:(NGMissionRecord *)missionRecord;

/**
 *  统计消费
 *
 *  @param consumptionRecord 消费信息
 */
+ (void)consumption:(NGConsumptionRecord *)consumptionRecord;

/**
 *  统计剩余虚拟币
 *
 *  @param coinRecord 剩余虚拟币信息
 */
+ (void)coin:(NGCoinRecord *)coinRecord;

@end
