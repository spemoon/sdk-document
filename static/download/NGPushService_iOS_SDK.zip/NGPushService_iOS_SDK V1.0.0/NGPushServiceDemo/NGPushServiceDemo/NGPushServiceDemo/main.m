//
//  main.m
//  NGPushServiceDemo
//
//  Created by chisj on 14-9-18.
//  Copyright (c) 2014年 NGDS. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
