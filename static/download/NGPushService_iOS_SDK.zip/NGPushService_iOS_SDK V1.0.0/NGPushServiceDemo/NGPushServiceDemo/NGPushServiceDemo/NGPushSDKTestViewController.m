//
//  NGPushSDKTestViewController.m
//  NGPushService
//
//  Created by chisj on 14-9-17.
//  Copyright (c) 2014年 NGDS. All rights reserved.
//

#import "NGPushSDKTestViewController.h"
#import "NGPushService.h"
#import "NGPushServiceDefines.h"

@interface NGPushSDKTestViewController ()

@end

@implementation NGPushSDKTestViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"测试push sdk";
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return 8;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NGTestRecordSDKIdentify"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"NGTestRecordSDKIdentify"];
    }
    switch (indexPath.row) {
        case 0:
            cell.textLabel.text = @"支付记录";
            break;
        case 1:
            cell.textLabel.text = @"统计进入等级";
            break;
        case 2:
            cell.textLabel.text = @"统计离开等级";
            break;
        case 3:
            cell.textLabel.text = @"统计进入关卡";
            break;
        case 4:
            cell.textLabel.text = @"统计离开关卡";
            break;
        case 5:
            cell.textLabel.text = @"统计消费";
            break;
        case 6:
            cell.textLabel.text = @"统计剩余虚拟币";
            break;
        case 7:
            cell.textLabel.text = @"绑定playerID";
            break;
        default:
            break;
    }
    // Configure the cell...
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0: {
            NGPaymentRecord *paymentRecord = [[NGPaymentRecord alloc] init];
            paymentRecord.player_id = @"123";
            paymentRecord.channel_id = @"91_store"; 	       //渠道ID
            paymentRecord.channel_name = @"91手机助手";          //渠道名
            paymentRecord.amount = 100;					       //充值金额，浮点型，精确到小数点后两位
            paymentRecord.payment_channel = @"alipay";       //支付渠道，自定义字符串
            paymentRecord.currency = @"人民币";               //金额币种，自定义字符串
            paymentRecord.coin_amount = 1000;                //充值的游戏币
            paymentRecord.order_id = @"201409190001";        //订单号，字符串，由游戏客户端定义。
            paymentRecord.level = 50;					      //玩家等级
            paymentRecord.server_id = @"AppStore_1";         //服务器ID
            paymentRecord.server_name = @"AppStore服务器1";   //服务器名
            [NGPushService pay:paymentRecord];
        }
            break;
        case 1: {
            NGLevelRecord *levelRecord = [NGLevelRecord new];
            levelRecord.player_id = @"123";
            levelRecord.channel_id = @"91_store";            //渠道ID
            levelRecord.channel_name = @"91手机助手";         //渠道名
            levelRecord.server_id = @"AppStore_1";           //服务器ID
            levelRecord.server_name = @"AppStore服务器1";     //服务器名
            levelRecord.player_level = 50;                   //玩家等级，0-100的数字
            [NGPushService reachLevel:levelRecord];
        }
            break;
        case 2:
        {
            NGLevelRecord *levelRecord = [NGLevelRecord new];
            levelRecord.player_id = @"123";
            levelRecord.channel_id = @"91_store";               //渠道ID
            levelRecord.channel_name = @"91手机助手";            //渠道名
            levelRecord.server_id = @"AppStore_1";
            levelRecord.server_name = @"AppStore服务器1";        //服务器名
            levelRecord.player_level = 50;
            [NGPushService leaveLevel:levelRecord];
        }
            break;
        case 3:{
            NGMissionRecord *missionRecord = [NGMissionRecord new];
            missionRecord.player_id = @"123";
            missionRecord.channel_id = @"91_store";             //渠道ID
            missionRecord.channel_name = @"91手机助手";          //渠道名
            missionRecord.server_id = @"AppStore_1";
            missionRecord.server_name = @"AppStore服务器1";      //服务器名
            missionRecord.mission_id = @"100001";               //关卡id
            missionRecord.mission_name = @"第一关：新手村";        //关卡名
            [NGPushService enterMission:missionRecord];
        }
            break;
        case 4:
        {
            NGMissionRecord *missionRecord = [NGMissionRecord new];
            missionRecord.player_id = @"123";
            missionRecord.channel_id = @"91_store";             //渠道ID
            missionRecord.channel_name = @"91手机助手";          //渠道名
            missionRecord.server_id = @"AppStore_1";
            missionRecord.server_name = @"AppStore服务器1";      //服务器名
            missionRecord.mission_id = @"100001";
            missionRecord.mission_name = @"第一关：新手村";        //关卡名
            [NGPushService leaveMission:missionRecord];
        }
            break;
        case 5:{
            NGConsumptionRecord *consumptionRecord = [NGConsumptionRecord new];
            consumptionRecord.player_id = @"123";
            consumptionRecord.channel_id = @"91_store";             //渠道ID
            consumptionRecord.channel_name = @"91手机助手";          //渠道名
            consumptionRecord.server_id = @"AppStore_1";
            consumptionRecord.server_name = @"AppStore服务器1";      //服务器名
            consumptionRecord.item_id = @"1000002";                 //消费的商品ID
            consumptionRecord.item_name = @"钻石60个";               //消费的商品名称
            consumptionRecord.item_amount = 1;                      //消费商品数量
            consumptionRecord.coin_amount = 100;                    //话费虚拟币
            [NGPushService consumption:consumptionRecord];
        }
            break;
        case 6:
        {
            NGCoinRecord *coinRecord = [NGCoinRecord new];
            coinRecord.player_id = @"123";
            coinRecord.channel_id = @"91_store";                    //渠道ID
            coinRecord.channel_name = @"91手机助手";                //渠道名
            coinRecord.server_id = @"AppStore_1";
            coinRecord.server_name = @"AppStore服务器1";           //服务器名
            coinRecord.coin_amount = 90000;                         //剩余虚拟币
            [NGPushService coin:coinRecord];
        }
            break;
        case 7:
            [NGPushService setLoginPlayerID:@"11234567890"];
            break;
        default:
            break;
    }
    
}
@end
