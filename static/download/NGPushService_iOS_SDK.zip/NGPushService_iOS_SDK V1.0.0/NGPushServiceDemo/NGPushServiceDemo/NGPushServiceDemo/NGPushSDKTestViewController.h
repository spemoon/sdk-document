//
//  NGPushSDKTestViewController.h
//  NGPushService
//
//  Created by chisj on 14-9-17.
//  Copyright (c) 2014年 NGDS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NGPushSDKTestViewController : UITableViewController

@end
