//
//  NGPushServiceDefines.h
//  NGSDK
//
//  Created by chisj on 14-9-15.
//  Copyright (c) 2014年 NGDS. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  充值记录
 */
@interface NGPaymentRecord : NSObject {

}

@property (nonatomic, strong) NSString *player_id;          //玩家id
@property (nonatomic, strong) NSString *channel_id;         //渠道id
@property (nonatomic,       ) float amount;                 //充值金额,浮点型，保留2位小数
@property (nonatomic, strong) NSString *payment_channel;    //支付渠道
@property (nonatomic, strong) NSString *currency;           //金额币种
@property (nonatomic,       ) NSUInteger coin_amount;       //充值游戏币个数
@property (nonatomic, strong) NSString *order_id;           //订单号
@property (nonatomic,       ) NSUInteger level;             //玩家等级
@property (nonatomic, strong) NSString *server_id;          //服务器ID

@end

/**
 *  游戏等级信息记录
 */
@interface NGLevelRecord : NSObject {

}

@property (nonatomic, strong) NSString *player_id;          //玩家id
@property (nonatomic, strong) NSString *channel_id;         //渠道id
@property (nonatomic, strong) NSString *server_id;          //服务器ID
@property (nonatomic,       ) NSInteger player_level;       //玩家等级

@end


/**
 *  任务关卡记录
 */
@interface NGMissionRecord : NSObject {

}

@property (nonatomic, strong) NSString *player_id;          //玩家id
@property (nonatomic, strong) NSString *channel_id;         //渠道id
@property (nonatomic, strong) NSString *server_id;          //服务器ID
@property (nonatomic,       ) NSInteger mission_id;         //关卡

@end

/**
 *  消费记录
 */
@interface NGConsumptionRecord : NSObject {

}

@property (nonatomic, strong) NSString *player_id;          //玩家id
@property (nonatomic, strong) NSString *channel_id;         //渠道id
@property (nonatomic, strong) NSString *server_id;          //服务器ID，字符串
@property (nonatomic,       ) NSInteger item_id;            //消费商品ID
@property (nonatomic,       ) NSInteger item_amount;        //消费商品数量
@property (nonatomic,       ) NSInteger coin_amount;        //消费虚拟币数量

@end


/**
 *  剩余虚拟币记录
 */
@interface NGCoinRecord : NSObject {

}

@property (nonatomic, strong) NSString *player_id;          //玩家id
@property (nonatomic, strong) NSString *channel_id;         //渠道id
@property (nonatomic, strong) NSString *server_id;          //服务器ID
@property (nonatomic,       ) NSInteger coin_amount;        //剩余虚拟币数量

@end
