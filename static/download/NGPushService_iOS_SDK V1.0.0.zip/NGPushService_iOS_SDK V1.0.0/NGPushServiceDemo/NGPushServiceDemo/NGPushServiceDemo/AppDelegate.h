//
//  AppDelegate.h
//  NGPushServiceDemo
//
//  Created by chisj on 14-9-18.
//  Copyright (c) 2014年 NGDS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
