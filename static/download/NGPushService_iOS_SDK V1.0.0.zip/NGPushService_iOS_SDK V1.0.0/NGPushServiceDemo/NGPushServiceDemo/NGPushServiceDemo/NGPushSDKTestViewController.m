//
//  NGPushSDKTestViewController.m
//  NGPushService
//
//  Created by chisj on 14-9-17.
//  Copyright (c) 2014年 NGDS. All rights reserved.
//

#import "NGPushSDKTestViewController.h"
#import "NGPushService.h"
#import "NGPushServiceDefines.h"

@interface NGPushSDKTestViewController ()

@end

@implementation NGPushSDKTestViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"测试push sdk";
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return 8;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NGTestRecordSDKIdentify"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"NGTestRecordSDKIdentify"];
    }
    switch (indexPath.row) {
        case 0:
            cell.textLabel.text = @"支付记录";
            break;
        case 1:
            cell.textLabel.text = @"统计进入等级";
            break;
        case 2:
            cell.textLabel.text = @"统计离开等级";
            break;
        case 3:
            cell.textLabel.text = @"统计进入关卡";
            break;
        case 4:
            cell.textLabel.text = @"统计离开关卡";
            break;
        case 5:
            cell.textLabel.text = @"统计消费";
            break;
        case 6:
            cell.textLabel.text = @"统计剩余虚拟币";
            break;
        case 7:
            cell.textLabel.text = @"绑定playerID";
            break;
        default:
            break;
    }
    // Configure the cell...
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0: {
            NGPaymentRecord *paymentRecord = [[NGPaymentRecord alloc] init];
            paymentRecord.player_id = @"123";
            paymentRecord.channel_id = @"14"; //渠道ID，可不填
            paymentRecord.amount = 100.11;
            paymentRecord.payment_channel = @"test";
            paymentRecord.currency = @"人民币";
            paymentRecord.coin_amount = 1000;
            paymentRecord.order_id = @"201409190001";
            paymentRecord.level = 50;
            paymentRecord.server_id = @"2";
            [NGPushService pay:paymentRecord];
        }
            break;
        case 1: {
            NGLevelRecord *levelRecord = [NGLevelRecord new];
            levelRecord.player_id = @"123";
            levelRecord.channel_id = @"14"; //渠道ID，可不填
            levelRecord.server_id = @"2";
            levelRecord.player_level = 50;
            [NGPushService reachLevel:levelRecord];
        }
            break;
        case 2:
        {
            NGLevelRecord *levelRecord = [NGLevelRecord new];
            levelRecord.player_id = @"123";
            levelRecord.channel_id = @"14"; //渠道ID，可不填
            levelRecord.server_id = @"2";
            levelRecord.player_level = 50;
            [NGPushService leaveLevel:levelRecord];
        }
            break;
        case 3:{
            NGMissionRecord *missionRecord = [NGMissionRecord new];
            missionRecord.player_id = @"123";
            missionRecord.channel_id = @"14"; //渠道ID，可不填
            missionRecord.server_id = @"2";
            missionRecord.mission_id = 11;
            [NGPushService enterMission:missionRecord];
        }
            break;
        case 4:
        {
            NGMissionRecord *missionRecord = [NGMissionRecord new];
            missionRecord.player_id = @"123";
            missionRecord.channel_id = @"14"; //渠道ID，可不填
            missionRecord.server_id = @"2";
            missionRecord.mission_id = 11;
            [NGPushService leaveMission:missionRecord];
        }
            break;
        case 5:{
            NGConsumptionRecord *consumptionRecord = [NGConsumptionRecord new];
            consumptionRecord.player_id = @"123";
            consumptionRecord.channel_id = @"14"; //渠道ID，可不填
            consumptionRecord.server_id = @"2";
            consumptionRecord.item_id = 1000;
            consumptionRecord.item_amount = 1;
            consumptionRecord.coin_amount = 100;
            [NGPushService consumption:consumptionRecord];
        }
            break;
        case 6:
        {
            NGCoinRecord *coinRecord = [NGCoinRecord new];
            coinRecord.player_id = @"123";
            coinRecord.channel_id = @"14"; //渠道ID，可不填
            coinRecord.server_id = @"2";
            coinRecord.coin_amount = 90000;
            [NGPushService coin:coinRecord];
        }
            break;
        case 7:
            [NGPushService setLoginPlayerID:@"11234567890"];
            break;
        default:
            break;
    }
    
}
@end
