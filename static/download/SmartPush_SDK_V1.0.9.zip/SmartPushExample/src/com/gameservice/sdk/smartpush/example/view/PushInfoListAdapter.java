package com.gameservice.sdk.smartpush.example.view;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.gameservice.sdk.smartpush.example.R;
import com.gameservice.sdk.smartpush.example.data.PushInfo;

import java.util.ArrayList;

public class PushInfoListAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<PushInfo> array;
    private int count;
    private LayoutInflater inflater;

    public PushInfoListAdapter(Context context, ArrayList<PushInfo> array) {
        this.context = context;
        this.array = array;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        count = array.size();
        return count;
    }

    @Override
    public Object getItem(int position) {
        return array.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.list_pushinfo_item, null);
            holder.title = (TextView) convertView.findViewById(R.id.pushinfo_title);
            holder.content = (TextView) convertView.findViewById(R.id.pushinfo_content);
            holder.type = (TextView) convertView.findViewById(R.id.pushinfo_type);
            holder.time = (TextView) convertView.findViewById(R.id.pushinfo_time);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.title.setText("标题：" + array.get(position).getTitle());
        holder.content.setText("内容：" + array.get(position).getContent());
        holder.type.setText("推送类型：" + array.get(position).getType());
        return convertView;
    }

    public final class ViewHolder {
        public TextView title;
        public TextView content;
        public TextView type;
        public TextView time;
    }
}