package com.gameservice.sdk.smartpush.example.view;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;
import com.gameservice.sdk.smartpush.example.R;
import com.gameservice.sdk.smartpush.example.base.BaseActivity;

/**
 * AboutActivity
 * Description:关于页面
 */
public class AboutActivity extends BaseActivity {

    private TextView mTvVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        // 初始化header
        initHeader();
        // 初始化view
        initView();
    }

    private void initView() {
        mTvVersion = (TextView) findViewById(R.id.about_version);
        try {
            PackageManager pm = getPackageManager();
            PackageInfo pi = null;
            pi = pm.getPackageInfo(getPackageName(), 0);
            mTvVersion.setText(getString(R.string.app_name) + " V" + pi.versionName);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void initHeader() {
        bindHeader(R.id.about_headfrg);
        mHeader.setCenterText(getString(R.string.about));
        mHeader.hideRightView();
    }
}
