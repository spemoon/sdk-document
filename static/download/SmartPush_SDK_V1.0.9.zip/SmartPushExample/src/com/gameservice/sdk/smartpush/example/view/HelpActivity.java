package com.gameservice.sdk.smartpush.example.view;

import android.os.Bundle;
import com.gameservice.sdk.smartpush.example.R;
import com.gameservice.sdk.smartpush.example.base.BaseActivity;

/**
 * HelpActivity
 * Description:帮助页面
 */
public class HelpActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        // 初始化header
        initHeader();
    }

    private void initHeader() {
        bindHeader(R.id.help_headfrg);
        mHeader.setCenterText(getString(R.string.help_center));
        mHeader.hideRightView();
    }
}
