package com.gameservice.sdk.smartpush.example;

import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.widget.ListView;
import com.gameservice.sdk.push.api.IMsgReceiver;
import com.gameservice.sdk.push.api.SmartPush;
import com.gameservice.sdk.smartpush.example.base.BaseActivity;
import com.gameservice.sdk.smartpush.example.data.PushInfo;
import com.gameservice.sdk.smartpush.example.view.PushInfoListAdapter;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

/**
 * MainActivity
 * Description:推送demo的主页面,向开发者展示了如何使用sdk
 */
public class MainActivity extends BaseActivity {
    private ListView mLvPushInfo;
    private View mEmptyView;
    private ArrayList<PushInfo> mPushInfoArray;
    private PushInfoListAdapter mPushInfoAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 初始化组件
        init();
        // Demo接收显示列表调试用，开发者不需在此调用
        new Timer().schedule(
            new TimerTask(){
            @Override
            public void run() {
                SmartPush.registerReceiver(new MessageReceiver());
            }
        }, 1000);

    }

    private void initHeader() {
        bindHeader(R.id.main_headfrg);
        mHeader.setCenterText(getString(R.string.app_name));
        mHeader.hideLeftView();
    }

    private void init() {
        initHeader();
        mLvPushInfo = (ListView) findViewById(R.id.lv_pushinfo_content);
        mEmptyView = findViewById(R.id.empty_view);
        mPushInfoArray = new ArrayList<PushInfo>();
        mPushInfoAdapter = new PushInfoListAdapter(getApplicationContext(), mPushInfoArray);
        mLvPushInfo.setAdapter(mPushInfoAdapter);
        mLvPushInfo.setEmptyView(mEmptyView);
    }



    private class MessageReceiver implements IMsgReceiver {
        @Override
        public void onMessage(String message) {
            // 处理透传消息 message是开发者在网站上填的消息内容
            //由于BaseApp中对message已做处理,此处 do nothing.
        }

        @Override
        public void onDebug(String debugInfo) {
            // SDK发出的debug信息，开发者不需处理
            try {
                JSONObject jsonObject = new JSONObject(debugInfo);
                PushInfo pushInfo = new PushInfo(jsonObject);
                mPushInfoArray.add(pushInfo);
                mPushInfoAdapter.notifyDataSetChanged();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onDeviceToken(String deviceToken) {
            //由于BaseApp中对token已做处理,此处 do nothing.
        }
    }

    @Override
    protected void onResume() {
        // 记录用户离开当前页面行为
        SmartPush.onActivityResume(this);
        super.onStart();
    }

    @Override
    protected void onPause() {
        // 记录用户返回当前页面行为
        SmartPush.onActivityPause(this);
        super.onPause();
    }
}
