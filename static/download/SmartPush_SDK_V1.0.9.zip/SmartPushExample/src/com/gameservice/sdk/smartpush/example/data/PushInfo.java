package com.gameservice.sdk.smartpush.example.data;

import org.json.JSONObject;

/**
 * PushInfo
 * Description:解析PushInfo的类
 */
public class PushInfo {

    private int push_type;
    private String title;
    private String content;
    private String time;
    private String type;

    private static final String FIELD_PUSH_TYPE = "push_type";
    private static final String FIELD_TITLE = "title";
    private static final String FIELD_CONTENT = "content";
    private static final String FIELD_TIME = "order_time";

    public PushInfo(JSONObject jsonObject) {
        if (jsonObject != null) {
            push_type = jsonObject.optInt(FIELD_PUSH_TYPE);
            title = jsonObject.optString(FIELD_TITLE);
            content = jsonObject.optString(FIELD_CONTENT);
            time = jsonObject.optString(FIELD_TIME);
            switch (push_type){
                case 1:
                    setType("启动应用");
                    break;
                case 2:
                    setType("下载");
                    break;
                case 3:
                    setType("打开网页");
                    break;
                case 4:
                    setType("启动应用指定页面");
                    break;
                case 5:
                    setType("透传消息");
                    break;
            }
        }
    }

    // 转换成Json串
    public JSONObject toJson() {
        return null;
    }

    public int getPush_type() {
        return push_type;
    }

    public void setPush_type(int push_type) {
        this.push_type = push_type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}
