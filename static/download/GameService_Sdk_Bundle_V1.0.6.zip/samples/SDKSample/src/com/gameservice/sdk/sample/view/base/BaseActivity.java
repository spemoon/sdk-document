package com.gameservice.sdk.sample.view.base;

import android.app.Activity;
import com.gameservice.sdk.GameService;

/**
 * BaseActivity
 * Description:基础activity，在onPause和onResume中实现统计功能
 */
public class BaseActivity extends Activity {
    @Override
    protected void onPause() {
        // 放到需要的页面去实现
//        GameService.onPause(this);
        super.onPause();
    }


    @Override
    protected void onResume() {
        // 放到需要的页面去实现
//        GameService.onResume(this);
        super.onResume();
    }
}
