package com.gameservice.sdk.sample.view.push;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;
import com.tgx.push.sdk.app.AbstractMsgReceiver;

/**
 * PushMessageReceiver
 * Description:推送信息接收者
 */
public class PushMessageReceiver extends AbstractMsgReceiver {
    private static final String TAG = "PushMessageReceiver";
    private static int P2P_MSG_COUNT;
    private static int P2P_MSG_COUNT_OTHER;

    public PushMessageReceiver(Context ctx) {
        super(ctx);
    }

    @Override
    public void onImReceive(long fromUid, long toUid, String msg) {
        onHandleIm(fromUid, toUid, msg);
        String msgLog = new StringBuilder().append("msg From ").append(fromUid)
                .append(" To ").append(toUid).append(" content is ").append(msg).toString();
        Toast.makeText(getContext(), msgLog, Toast.LENGTH_LONG).show();
//        Log.d(TAG, "P2P_MSG_COUNT p2p counts:  --------------   "+ P2P_MSG_COUNT++ );
        debugMsgForDev("onImReceive:" + msgLog);
    }

    @Override
    public void onMessage(String s) {
        debugMsgForDev("onMessage:" + s);
        Log.d(TAG, "onReceiveMsg:" + s);
        Toast.makeText(getContext(), s, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onDebug(String message) {
        super.onDebug(message);
        debugMsgForDev("onDebug:" + message);
        Log.d(TAG, "onPushDebug:" + message);
//        Log.d(TAG, "P2P_MSG_COUNT_OTHER p2p counts:  --------------   "+ P2P_MSG_COUNT_OTHER++ );

    }

    private void debugMsgForDev(String message) {
        Intent intent = new Intent(PushServiceActivity.MSG_DEBUG_INTENT);
        intent.putExtra(PushServiceActivity.MSG_DEBUG_KEY, message);
        getContext().sendBroadcast(intent);
    }
}
