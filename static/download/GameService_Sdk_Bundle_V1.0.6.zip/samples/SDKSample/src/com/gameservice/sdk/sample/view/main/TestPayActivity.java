package com.gameservice.sdk.sample.view.main;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.gameservice.sdk.GameService;
import com.gameservice.sdk.OnPayListener;
import com.gameservice.sdk.Order;
import com.gameservice.sdk.StatusCode;
import com.gameservice.sdk.sample.R;
import com.gameservice.sdk.sample.view.base.BaseActivity;

import java.text.SimpleDateFormat;
import java.util.Date;


public class TestPayActivity extends BaseActivity implements View.OnClickListener {
    private static final String TAG = "GameServiceTest";
    EditText edtProduct;
    EditText edtMoney;
    EditText edtDesc;
    EditText edtOrderNo;
    EditText edtUserId;
    EditText edtUserName;
    EditText edtUrl;

    Button btnPay;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_pay);

    }

    @Override public void onContentChanged() {
        super.onContentChanged();

        edtProduct = (EditText) findViewById(R.id.edtProduct);
        edtMoney = (EditText) findViewById(R.id.edtMoney);
        edtDesc = (EditText) findViewById(R.id.edtDesc);
        edtOrderNo = (EditText) findViewById(R.id.edtOrderNo);
        edtUserId = (EditText) findViewById(R.id.edtUserId);
        edtUserName = (EditText) findViewById(R.id.edtUserName);
        edtUrl = (EditText) findViewById(R.id.edtUrl);

        btnPay = (Button) findViewById(R.id.btnPay);
        btnPay.setOnClickListener(this);

        edtOrderNo.setText(getOutTradeNo());
    }

    @Override public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.btnPay:
                doPay();
                break;
            default:
                break;
        }
    }

    /**
     * 调用支付功能
     */
    public void doPay() {
        Order order = testOrder();
        // 生成待签名字符串
        String orderStr = getOrderString(order);
        Log.d(TAG, "orderStr:" + orderStr);
        // 签名
        order.setSign(Rsa.sign(orderStr, Keys.PRIVATE));
        Log.d(TAG, "signStr: " + order.getSign());
        GameService.pay(this, order, new OnPayListener() {
            @Override public void finish(int code, String msg) {
                switch (code) {
                    case StatusCode.FINISH:
                        msg = "支付完成";
                        break;
                    case StatusCode.CANCEL:
                        msg = "取消支付";
                        break;
                    default:
                        break;
                }
                Toast.makeText(TestPayActivity.this, msg, Toast.LENGTH_LONG).show();
                Log.d(TAG, "onPay: " + code + ": " + msg);
            }
        });
    }

    /**
     * 生成测试订单
     * @return
     */
    public Order testOrder() {
        ApplicationInfo appInfo = null;
        try {
            appInfo = getPackageManager()
                .getApplicationInfo(getPackageName(),
                    PackageManager.GET_META_DATA);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        Order result = new Order();
        result.setAppId(getString(
            R.string.sdk_appid));                                                     // 应用ID
        result.setChannelId(appInfo.metaData.getInt("NGDS_CHANNEL"));                 // 渠道ID
        result.setOrderId(getOutTradeNo());                                           // 订单号
        result.setUserId(edtUserId.getText().toString());                             // 用户ID
        result.setUserName(edtUserName.getText().toString());                         // 用户名称
        result.setSubject(edtProduct.getText().toString() + result.getOrderId());     // 商品名称
        result.setBody(edtDesc.getText().toString());                                 // 商品描述
        result.setMoney(Integer.valueOf(edtMoney.getText().toString()));              // 商品价格：单位 分
        result.setNotifyUrl(edtUrl.getText().toString());                             // 回调地址
        result.setImei("imeixxx");                                                    // IMEI
        result.setMacAddress("05-16-DC-59-C2-34");                                    // MAC地址
        result.setExtInfo("extra string");                                            // 扩展信息

        return result;
    }

    /**
     * 生成订单号
     * @return
     */
    private String getOutTradeNo() {
        SimpleDateFormat format = new SimpleDateFormat("MMddHHmmss");
        Date date = new Date();
        String key = format.format(date);

        java.util.Random r = new java.util.Random();
        key += r.nextInt();
        key = key.substring(0, 15);
        Log.d(TAG, "outTradeNo: " + key);
        return key;
    }

    /**
     * 按参数字母顺序组合订单字符串，去掉空值
     *
     * @param obj
     * @return
     */
    private String getOrderString(Order obj) {
        StringBuilder sb = new StringBuilder();
        sb.append("amount=" + obj.getMoney());
        sb.append("&app_id=" + obj.getAppId());
        sb.append("&app_order_id=" + obj.getOrderId());
        sb.append("&app_user_id=" + obj.getUserId());
        sb.append("&app_user_name=" + obj.getUserName());
        sb.append("&body=" + obj.getBody());
        sb.append("&channel_id=" + obj.getChannelId());
        sb.append("&ext=" + obj.getExtInfo());
        sb.append("&imei=" + obj.getImei());
        sb.append("&mac_address=" + obj.getMacAddress());
        sb.append("&notify_url=" + obj.getNotifyUrl());
        sb.append("&subject=" + obj.getSubject());

        return new String(sb);
    }
    //
    //    @Override
    //    protected void onPause() {
    //        GameService.onPause(this);
    //        super.onPause();
    //    }
    //
    //
    //    @Override
    //    protected void onResume() {
    //        GameService.onResume(this);
    //        super.onResume();
    //    }
}
