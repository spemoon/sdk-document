package com.gameservice.sdk.sample.view.main;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import com.gameservice.sdk.GameService;
import com.gameservice.sdk.OAuthInfo;
import com.gameservice.sdk.OnLoginListener;
import com.gameservice.sdk.StatusCode;
import com.gameservice.sdk.sample.R;
import com.gameservice.sdk.sample.base.SDKDemoConstants;
import com.gameservice.sdk.sample.view.base.BaseActivity;

public class MainActivity extends BaseActivity implements View.OnClickListener, SDKDemoConstants {

    private static final String TAG = "GameServiceTest";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.btnLogin).setOnClickListener(this);
        findViewById(R.id.btnPay).setOnClickListener(this);
        findViewById(R.id.btn_push_service).setOnClickListener(this);
        findViewById(R.id.btnLogout).setOnClickListener(this);
        // 横屏，在调用页面接口前设置
        GameService.setScreenOrientation(GameService.SCREEN_ORIENTATION_LANDSCAPE);
    }

    // 调用登录
    private void doLogin() {
        if (GameService.getOAuthInfo(this) == null) {
            GameService.login(MainActivity.this, false, new OnLoginListener() {
                @Override
                public void finish(int code, OAuthInfo oAuthInfo) {
                    String msg = "";
                    switch (code) {
                        case StatusCode.FINISH:
                            if (oAuthInfo != null) {
                                msg = "token: " + oAuthInfo.getAccessToken();
                            }
                            break;
                        case StatusCode.CANCEL:
                            msg = "跳过登录";
                            break;
                        default:
                            break;
                    }
                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
                    Log.d(TAG, +code + ": " + msg);
                }
            });
        } else {
            String msg = "你已经是登录状态了，不需要再执行登录操作";
            Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
            Log.d(TAG, msg);
        }
    }

    // 调用注销登录
    private void doLogout() {
        String msg = "";
        if (GameService.getOAuthInfo(this) == null) {
            msg = "你还没有登录，无法执行注销登录操作";
        } else {
            boolean result = GameService.logout(this);
            if (result) {
                msg = "注销登录成功";
            } else {
                msg = "注销登录失败";
            }
        }
        Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
        Log.d(TAG, msg);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.btnLogin:
                doLogin();
                break;
            case R.id.btnLogout:
                doLogout();
                break;
            case R.id.btnPay:
                Intent intent =
                    new Intent(this, com.gameservice.sdk.sample.view.main.TestPayActivity.class);
                startActivity(intent);
                break;

            case R.id.btn_push_service:
                Intent pushServiceIntent = new Intent(this,
                    com.gameservice.sdk.sample.view.push.PushServiceActivity.class);
                startActivity(pushServiceIntent);
                break;
            default:
                break;
        }
    }


}
