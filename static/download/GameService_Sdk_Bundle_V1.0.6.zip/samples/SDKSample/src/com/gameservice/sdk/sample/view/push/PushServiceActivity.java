package com.gameservice.sdk.sample.view.push;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import com.gameservice.sdk.GameService;
import com.gameservice.sdk.sample.R;
import com.gameservice.sdk.sample.base.SDKDemoConstants;
import com.gameservice.sdk.sample.view.base.BaseActivity;

/**
 * PushServiceActivity
 * Description: provide function of push service
 *
 * @author walker_lx
 */
public class PushServiceActivity extends BaseActivity implements View.OnClickListener, SDKDemoConstants {
    private TextView         mTvAppId;
    private TextView         mTvAppSecret;
    private TextView         mTvTuid;
    private TextView         mTvDebugContent;
    private Button           mBtnStartService;
    private Button           mBtnStopService;
    private Button           mBtnUserLogin;
    private Button           mBtnUserLogout;
    private Button           mBtnSendMsg;
    private MsgDebugReceiver mMsgDebugReceiver;
    private ScrollView       mSvDebugContent;
    public final static  String MSG_DEBUG_INTENT        = "msg_debug_intent";
    public final static  String MSG_DEBUG_KEY           = "msg_debug_key";
    private final static int    DEBUG_LINES_RESTRICTION = 40;
    private int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_push);
        initView();
        registerListener();
        initData();
        registerReceiver(mMsgDebugReceiver, new IntentFilter(MSG_DEBUG_INTENT));
    }


    @Override
    protected void onDestroy() {
        unregisterReceiver(mMsgDebugReceiver);
        super.onDestroy();
    }

    private void initView() {
        mTvAppId = (TextView) findViewById(R.id.tv_appkey);
        mTvAppSecret = (TextView) findViewById(R.id.tv_appsecret);
        mTvTuid = (TextView) findViewById(R.id.tv_tuid);
        mTvDebugContent = (TextView) findViewById(R.id.tv_debug_content);
        mBtnStartService = (Button) findViewById(R.id.btn_start_service);
        mBtnStopService = (Button) findViewById(R.id.btn_stop_service);
        mBtnUserLogin = (Button) findViewById(R.id.btn_player_login);
        mBtnUserLogout = (Button) findViewById(R.id.btn_player_logout);
        mBtnSendMsg = (Button) findViewById(R.id.btn_send_msg);
        mSvDebugContent = (ScrollView) findViewById(R.id.sv_debug_content);
    }

    private void registerListener() {
        mBtnStartService.setOnClickListener(this);
        mBtnStopService.setOnClickListener(this);
        mBtnUserLogin.setOnClickListener(this);
        mBtnUserLogout.setOnClickListener(this);
        mBtnSendMsg.setOnClickListener(this);
    }

    private void initData() {
        mTvAppId.setText(getString(R.string.app_id, getString(com.tgx.push.sdk.R.string.sdk_appid)));
        mTvAppSecret.setText(getString(R.string.app_secret, getString(com.tgx.push.sdk.R.string.sdk_appkey)));
        mTvTuid.setText(getString(R.string.push_uid_arg, getTuid()));
        mMsgDebugReceiver = new MsgDebugReceiver();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_start_service:
                startPushSdk();
                break;
            case R.id.btn_stop_service:
                stopPushSdk();
                break;
            case R.id.btn_player_login:
                //此处为了测试p2p消息发送一次性注册了两个用户id，在实际开发中注册一个即可
                GameService.onPlayerLogin(this, PLAYER_ID_ANOTHER);
                GameService.onPlayerLogin(this, PLAYER_ID);
                mTvTuid.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mTvTuid.setText(getString(R.string.push_uid_arg, getTuid()));
                    }
                }, 1500);
                break;
            case R.id.btn_player_logout:
                GameService.onPlayerLogout(this);
                mTvTuid.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mTvTuid.setText(getString(R.string.push_uid_arg, getTuid()));
                    }
                }, 1500);
                break;
            case R.id.btn_send_msg:
                GameService.sendMsg(this, PLAYER_ID_ANOTHER, PLAYER_ID, ++count + ": send msg");
                break;


        }
    }

    private String getTuid() {
        String uid = GameService.getTuid(this);
        return null == uid ? "未登入" : uid;
    }

    /**
     * 停止推送服务
     */
    private void stopPushSdk() {
        GameService.stopPushService(this);
    }

    /**
     * 开始推送服务
     */
    private void startPushSdk() {
        //要正常的使用推送服务，必须注册一个父类为AbstractMsgReceiver的信息接收者，并在里面处理相关信息，PushMessageReceiver已展示。
        GameService.registerMsgReceiver(PushMessageReceiver.class);
        //进行推送服务的前必须为应用打上tag，tag可以任意的.
        GameService.setPushTags(getApplicationContext(), new String[]{"sdkdemo"}, null);
        GameService.startPushService(this);
    }


    /**
     * 消息debug信息接收者
     */
    class MsgDebugReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String msg = intent.getStringExtra(MSG_DEBUG_KEY);
            if (!TextUtils.isEmpty(msg) && null != mTvDebugContent) {
                clearDebugText();
                mTvDebugContent.append(msg + "\r\n");
                mSvDebugContent.fullScroll(ScrollView.FOCUS_DOWN);
            }
        }
    }

    private void clearDebugText() {
        if (mTvDebugContent.getLineCount() > DEBUG_LINES_RESTRICTION) {
            mTvDebugContent.setText("");
        }
    }

    @Override
    protected void onPause() {
        GameService.onPause(this);
        super.onPause();
    }


    @Override
    protected void onResume() {
        GameService.onResume(this);
        super.onResume();
    }
}
