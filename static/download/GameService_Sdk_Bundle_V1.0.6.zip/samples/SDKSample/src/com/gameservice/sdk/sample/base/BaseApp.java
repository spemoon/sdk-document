package com.gameservice.sdk.sample.base;

import android.app.Application;
import com.gameservice.sdk.GameService;
import com.gameservice.sdk.collection.util.error.NGDSCrashHandler;

/**
 * BaseApp
 * Description: 基础application，用于在初始化的时候做一些事情
 */
public class BaseApp extends Application {
    //系统默认的UncaughtException处理类
    private Thread.UncaughtExceptionHandler mDefaultUncaughtExceptionHandler;

    @Override
    public void onCreate() {
        super.onCreate();
        initErrorHandler();

    }

    private void initErrorHandler() {
        mDefaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        //设置该CrashHandler为程序的默认处理器，帮助我们收集错误信息以反馈用户更好体验
        Thread.setDefaultUncaughtExceptionHandler(new NGDSCrashHandler(this, mDefaultUncaughtExceptionHandler));
    }

}
