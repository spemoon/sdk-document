package com.gameservice.sdk.sample.view.main;

/**
 * 可以使用压缩包中的openssl RSA密钥生成工具，生成一套RSA公私钥。
 * 这里签名时，只需要使用生成的RSA私钥。
 * Note: 为安全起见，使用RSA私钥进行签名的操作过程，应该尽量放到开发者服务器端去进行。
 *
 * RSA密钥生成命令
 生成RSA私钥
 openssl>genrsa -out rsa_private_key.pem 1024
 生成RSA公钥
 openssl>rsa -in rsa_private_key.pem -pubout -out rsa_public_key.pem
 将RSA私钥转换成PKCS8格式
 openssl>pkcs8 -topk8 -inform PEM -in rsa_private_key.pem -outform PEM -nocrypt

 注意：“>”符号后面的才是需要输入的命令。
 */
public final class Keys {

    //开发者私钥，自助生成，需pkcs8转换
    public static final String PRIVATE = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAPX9J7GOYsgDJgtjGXf43SbRlw5uG74Sg5pow5Fxc/l1kHtsmCvcfju/K8UP6GEiSi8SwcREh8zPEfOLvAQSkhAq+YxIaMunRIAPYl5OPPD1GZr2dxciOP3yGcivtT9hDuv/OeE3r4pSYwKCJfhzLC2H6+Gnhgjhr7tGGghXgvSXAgMBAAECgYAaycvl0Sy+vWEKQmuGnipvTMnXf3Qz+c4tJZWOpD1OAFiQqF3WAPgaR5JbroTO9y3+/FrvpcroKfC5hhEenGsdcvYoG88Ft92+JSseezMFjqA6M/RAVZSP7LT1/ZnMwYXk1/dnvDACp2RTpd3ShVpK6Ug0TuICl9AzooaBdqzs6QJBAP+aT37MplEmS0lJFq9AhNXuCGLij1RGtfFrVjTl3X1JUaydS1CXmY8T07DvSxOVjojuVKgotQhRVz8qo1KW0+UCQQD2XwUMNvmmxZKKJsd77G7upYjinr4wRKe6fTWW1OS60lLEqt9OXuVXjuvgw5gh5lA9+RTwgNI5LutfRsXcMlbLAkEAm+NfDHSAEwoJ7J5Y6XWuDlNoZfbLd5jQqnbOUuDGnvyyhVZBctui2fI7r7Oh1EXocnb4xr5c+r+xOGMmzN4USQJBALcyWLKIfoMADsMjqtn/KU3TUUISACIsKvyE9kA99gblNh5/YKUJ80d0QvlS9+DdPXWXrXZYk/lpZiPmoGHoHJkCQFiJX3uMSjq5WMqBn/S521mww4EWpJpH6lPt3DpbAAgExyeXFipQNBhsO2ciLAdUTUPB4ROqnOC4xMYJMuv8WD0=";
}
