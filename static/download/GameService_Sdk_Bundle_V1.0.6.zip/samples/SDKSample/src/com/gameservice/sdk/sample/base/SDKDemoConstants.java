package com.gameservice.sdk.sample.base;

/**
 * SDKDemoConstants
 * Description: demo常量
 */
public interface SDKDemoConstants {
    public static final String PLAYER_ID         = "ngdsTuid";
    public static final String PLAYER_ID_ANOTHER = "ngdsTuid1";
}
