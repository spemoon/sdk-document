<?php
/* *
 * 新游接口RSA函数
 * 详细：RSA签名、验签、解密
 * 版本：1.0
 * 说明：
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究新游接口使用，只是提供一个参考。
 */

function pkcs8_to_pem($der) {

    static $BEGIN_MARKER = "-----BEGIN PRIVATE KEY-----";
    static $END_MARKER = "-----END PRIVATE KEY-----";

    $value = base64_encode($der);

    $pem = $BEGIN_MARKER . "\n";
    $pem .= chunk_split($value, 64, "\n");
    $pem .= $END_MARKER . "\n";

    return $pem;
}

/**
 * RSA签名
 * @param string $data 待签名数据
 * @param string $private_key_path 商户私钥文件路径
 * @return bool 签名结果
 */
function rsaSign($data, $private_key_path) {
    $priKey = file_get_contents($private_key_path);
    $priKey = pkcs8_to_pem($priKey);
    $res = openssl_pkey_get_private($priKey);
    openssl_sign($data, $sign, $priKey);
    openssl_free_key($res);
	//base64编码
    $sign = base64_encode($sign);
    return $sign;
}

/**
 * RSA验签
 * @param string $data 待签名数据
 * @param string $public_key_path 新游的公钥文件路径
 * @param string $sign 要校对的的签名结果
 * @return bool 验证结果
 */
function rsaVerify($data, $public_key_path, $sign)  {
	$pubKey = file_get_contents($public_key_path);
    $res = openssl_get_publickey($pubKey);
    $result = (bool)openssl_verify($data, base64_decode($sign), $res);
    openssl_free_key($res);    
    return $result;
}

/**
 * RSA解密
 * @param string $content 需要解密的内容，密文
 * @param string $private_key_path 商户私钥文件路径
 * @return string 解密后内容，明文
 */
function rsaDecrypt($content, $private_key_path) {
    $priKey = file_get_contents($private_key_path);
    $res = openssl_get_privatekey($priKey);
	//用base64将内容还原成二进制
    $content = base64_decode($content);
	//把需要解密的内容，按128位拆开解密
    $result  = '';
    for($i = 0; $i < strlen($content)/128; $i++  ) {
        $data = substr($content, $i * 128, 128);
        openssl_private_decrypt($data, $decrypt, $res);
        $result .= $decrypt;
    }
    openssl_free_key($res);
    return $result;
}
