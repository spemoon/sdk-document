
            ╭───────────────────────╮
    ────┤           新游代码示例结构说明             ├────
            ╰───────────────────────╯ 

　 　    代码版本：1.0
         开发语言：PHP

    ─────────────────────────────────

───────
 代码文件结构
───────

PHP
  │
  ├lib┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈类文件夹
  │  │
  │  ├core.function.php ┈┈┈┈┈┈新游接口公用函数文件
  │  │
  │  ├notify.class.php┈┈┈┈┈┈┈新游通知处理类文件
  │  │
  │  └rsa.function.php┈┈┈┈┈┈┈新游接口RSA函数文件
  │
  ├log.txt┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈日志文件
  │
  ├config.php┈┈┈┈┈┈┈┈┈┈┈┈基础配置类文件
  │
  ├notify_url.php ┈┈┈┈┈┈┈┈┈┈┈┈┈服务器异步通知页面文件
  │
  ├key┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈私钥公钥文件夹（用法见下方※注意※）
  │  │
  │  ├rsa_private_key.pem┈┈┈┈┈┈┈┈┈商户的私钥文件
  │  │
  │  └newgame_public_key.pem┈┈┈┈┈┈┈┈新游的公钥文件
  │
  ├openssl┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈缺省dll文件（用法见下方※注意※）
  │  │
  │  ├libeay32.dll
  │  │
  │  ├ssleay32.dll
  │  │
  │  └php_openssl.dll
  │
  └readme.txt ┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈使用说明文本

※注意※

1、需要配置的文件是：
config.php
notify_url.php
key文件夹


3、秘钥解答：
●商户的私钥、商户的公钥、新游公钥

key文件夹里面须存放.pem后缀名的商户私钥、新游的公钥两个文件。

◆商户的私钥
1、必须保证只有一行文字，即，没有回车、换行、空格等
2、不需要对刚生成的（原始的）私钥做pkcs8编码
3、不需要去掉去掉“-----BEGIN PUBLIC KEY-----”、“-----END PUBLIC KEY-----”
简言之，只要维持刚生成出来的私钥的内容即可。

◆商户的公钥
1、必须保证只有一行文字，即，没有回车、换行、空格等
2、去掉“-----BEGIN PUBLIC KEY-----”、“-----END PUBLIC KEY-----”，只保存这两条文字之中的部分
3、保存好后，在开发者平台提交给新游。

◆新游公钥
1、必须保证只有一行文字，即，没有回车、换行、空格等
2、须保留“-----BEGIN PUBLIC KEY-----”、“-----END PUBLIC KEY-----”这两条文字。
简言之，新游公钥只需要维持原样即可。


●openssl文件夹中的3个DLL文件用法

1、如果你的系统是windows系统，且system32文件目录下没有libeay32.dll、ssleay32.dll这两个文件
   那么需要拷贝这两个文件到system32文件目录中

2、如果您的php安装目录下（php\ext）中没有php_openssl.dll
   那么请把php_openssl.dll放在这个文件夹中

─────────
 类文件函数结构
─────────

core.function.php

function createLinkstring($para)
功能：把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
输入：Array  $para 需要拼接的数组
输出：String 拼接完成以后的字符串

function createLinkstringUrlencode($para)
功能：把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串，并对参数值urlencode
输入：Array  $para 需要拼接的数组
输出：String 拼接完成以后的字符串

function paraFilter($para)
功能：除去数组中的空值和签名参数
输入：Array  $para 签名参数组
输出：Array  去掉空值与签名参数后的新签名参数组

function argSort($para)
功能：对数组排序
输入：Array  $para 排序前的数组
输出：Array  排序后的数组

function logResult($word='')
功能：写日志，方便测试（看网站需求，也可以改成存入数据库）
输入：String $word 要写入日志里的文本内容 默认值：空值


┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉

rsa.function.php

function sign($data, $private_key_path)
功能：RSA签名
输入：String $data 待签名数据
      String $private_key_path 商户私钥文件路径
输出：String 签名结果

function verify($data, $public_key_path, $sign)
功能：RSA验签
输入：String $data 待签名数据
      String $public_key_path 新游的公钥文件路径
      String $sign 要校对的的签名结果
输出：bool 验证结果

function decrypt($content, $private_key_path)
功能：RSA解密
输入：String $content 需要解密的内容，密文
      String $private_key_path 商户私钥文件路径
输出：String 解密后内容，明文

┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉


notify.class.php

function verifyNotify()
功能：对notify_url的认证
输出：Bool  验证结果：true/false

function verifyReturn()
功能：对return_url的认证
输出：Bool  验证结果：true/false

function getSignVerify($para_temp, $sign)
功能：获取返回时的签名验证结果
输入：Array $para_temp 通知返回来的参数数组
      String $sign 新游返回的签名结果
输出：Bool 获得签名验证结果
