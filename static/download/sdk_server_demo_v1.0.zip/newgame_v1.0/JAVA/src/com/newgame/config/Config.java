package com.newgame.config;

/* *
 *类名：Config
 *功能：基础配置类
 *详细：设置帐户有关信息及返回路径
 *版本：1.0
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究新游接口使用，只是提供一个参考。
 */

public class Config {
	
	//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
	// 商户的私钥
	public static String private_key = "MIICXQIBAAKBgQDmfGTWgHXaMGNNuA1iowH131OYhzaUqq8dSQ9F9i0ZIQJp8mjGYBsUoJ0N8Fn2KBhzlTO+r21OeY2Us3ekkjH3/f6hDDZxtVhuiX5rfogJPSsHKYkc/JYOk5f7XXsYoeNyszd5arGkjcQDGyiI02QcNF+/lt9Om1v/eb/Sr3fF5wIDAQABAoGALpWp0+j26PiquYSfv/XuaYGP5d4+W+H7rtGbcqqFBvUzBbLnFmFKV+r2k2Cm7ifAeWwIn1vZnejXgtybK/oYewLn6wWWzgRfi36z18VW8tWEcSsdozzxY3Naj9imMEuybBjPP/zsbFZyDD5qliy0set1m3XvlsDi2fLzjSJFqhECQQD80d7VmYAuyF/9J/Nq/yzFTTlTL5pr5V8Vi932BIXgI4iXjp8xeLO0zmjfTlOGsQ/Gv3DWqdy1C9pZunk8R3WdAkEA6WKamnUjZ3STtB/rlnpJHQG8/jlh5Fy5JC2uaFAYWCyIraBpHvgOcGUkaPHQWebota9Tb8o1KpUMKLBZdA/0UwJBAJBE2todDC6mHVCDOb62+r9kP/AeXApyC35qIDFBh3vOCyYhNuquLC5jEylKsxNLeus5V5THvbB6oRFO/dvOE2kCQQCaWmyF2xMfSSqm5rWZQCc61/t259yme+y20L+YneB78Hg03PKpWMWz8DC0d7mku+MMxngYZ1PiZdE01+1RpXuhAkBAaXUnsqaCAN37YNY5wNKmGkYwd5iLAyKUOtCfUwksogxH/QwiCn1/MSDTtvrRZF0gSI6+BWs8tyuZutr5RBLV";
	// 新游的公钥，无需修改该值
	public static String ali_public_key  = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC92UTOaQHUmLO/1+sCkpfvRGhmq8p0f3ZyBqkAriMkrG73p+To7Q2+jmTZDHLZERbfpUFBpA/so4qLKXYCXdOsTacCXjpu3lnnfqwBDid+vt++0dKoXpXbO1GBQ1eXdvV0SdcyIEkCIn+U8/0+hi5C8jowAg3gbpk7qe4MIDAN1QIDAQAB";

	//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
	

	// 调试用，创建TXT日志文件夹路径
	public static String log_path = "D:\\";

	// 字符编码格式 目前支持 utf-8
	public static String input_charset = "utf-8";
	
	// 签名方式 不需修改
	public static String sign_type = "RSA";

}
