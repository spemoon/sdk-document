package com.newgame.util;

import java.util.Map;

import com.newgame.config.Config;
import com.newgame.sign.RSA;

/* *
 *类名：Notify
 *功能：新游通知处理类
 *详细：处理新游各接口通知返回
 *版本：1.0
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究新游接口使用，只是提供一个参考

 *************************注意*************************
 *调试通知返回时，可查看或改写log日志的写入TXT里的数据，来检查通知返回是否正常
 */
public class Notify {

    /**
     * 验证消息是否是新游发出的合法消息
     * @param params 通知返回来的参数数组
     * @return 验证结果
     */
    public static boolean verify(Map<String, String> params) {

        //isSign不是true，与安全校验码、请求时的参数格式（如：带自定义参数等）、编码格式有关
	    String sign = "";
	    if(params.get("sign") != null) {sign = params.get("sign");}
	    boolean isSign = getSignVerify(params, sign);

        //写日志记录（若要调试，请取消下面两行注释）
        //String sWord = "responseTxt=" + responseTxt + "\n isSign=" + isSign + "\n 返回回来的参数：" + Core.createLinkString(params);
	    //Core.logResult(sWord);

        return isSign;
    }

    /**
     * 根据反馈回来的信息，生成签名结果
     * @param Params 通知返回来的参数数组
     * @param sign 比对的签名结果
     * @return 生成的签名结果
     */
	private static boolean getSignVerify(Map<String, String> Params, String sign) {
    	//过滤空值、sign与sign_type参数
    	Map<String, String> sParaNew = Core.paraFilter(Params);
        //获取待签名字符串
        String preSignStr = Core.createLinkString(sParaNew);
        //获得签名验证结果
        boolean isSign = false;
        if(Config.sign_type.equals("RSA")){
        	isSign = RSA.verify(preSignStr, sign, Config.ali_public_key, Config.input_charset);
        }
        return isSign;
    }

    public static String sign(Map<String, String> Params) {
        //过滤空值、sign与sign_type参数
        Map<String, String> sParaNew = Core.paraFilter(Params);
        //获取待签名字符串
        String preSignStr = Core.createLinkString(sParaNew);

        return RSA.sign(preSignStr, Config.private_key, Config.input_charset);
    }

    public static String signString(Map<String, String> Params) {
        //过滤空值、sign与sign_type参数
        Map<String, String> sParaNew = Core.paraFilter(Params);
        //获取待签名字符串
        String preSignStr = Core.createLinkString(sParaNew);

        return preSignStr;
    }
}
