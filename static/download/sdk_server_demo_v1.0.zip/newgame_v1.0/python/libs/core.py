# !-*- coding:utf-8 -*-

__author__ = 'lost'

import urllib
from collections import OrderedDict


def to_string(val):
    if isinstance(val, int) or isinstance(val, long) or isinstance(val, float):
        return str(val)
    else:
        return val.encode('utf-8')


def create_link_string(params):
    """把字典所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串

    :param params: dict 需要拼接的数组
    """
    args = ''
    for key, val in params.iteritems():
        args += key + '=' + to_string(val) + '&'

    return args[0:-1]


def create_quote_link_string(params):
    """把字典所有元素，按照“参数="参数值"”的模式用“&”字符拼接成字符串

    :param params: dict 需要拼接的数组
    """
    args = ''
    for key, val in params.iteritems():
        args += key + '="' + to_string(val) + '"&'

    return args[0:-1]


def create_link_string_urlencode(params):
    """把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串，并对字符串做urlencode编码
    :param params: dict 需要拼接的数组
    """
    return urllib.urlencode(params)


def create_quote_link_string_urlencode(params):
    """把数组所有元素，按照'参数="参数值"'的模式用“&”字符拼接成字符串，并对字符串做urlencode编码
    :param params: dict 需要拼接的数组
    """
    args = ''
    for key, val in params.iteritems():
        args += key + '="' + urllib.quote_plus(to_string(val)) + '"&'

    return args[0:-1]


def para_filter(params, filter_params=None):
    """除去数组中的空值和签名参数

    :param params: dict 签名参数组
    """
    filtered_params = OrderedDict()

    if filter_params is None:
        filter_params = ['sign', 'sign_type']

    for key, val in params.iteritems():
        if key not in filter_params and val != '' and val is not None:
            filtered_params[key] = val
    return filtered_params


def arg_sort(d):
    """对数组排序

    :param d: dict 排序前的数组
    """
    return OrderedDict(sorted(d.items(), key=lambda t: t[0]))



