# !-*- coding:utf-8 -*-
from . import core
from .crypt import RSAUtils


class Notify(object):
    def __init__(self, config):
        self.rsa = RSAUtils(public_key=config.PUBLIC_KEY, private_key=config.PRIVATE_KEY)

    def verify_return(self, result):
        """针对return_url验证消息是否是支付宝发出的合法消息

        :param result: dict 返回结果
        """
        if not result or result.get('sign') is None:  # 判断参数是否为空
            return False
        else:
            # 验证签名结果
            return self.get_sign_verify(result, result.get('sign'))

    def get_sign_verify(self, para_temp, sign):
        """获取返回时的签名验证结果
          :param :para_temp 通知返回来的参数数组
          :param :sign 返回的签名结果
        """
        prestr = self.get_sign_str(para_temp)

        return self.rsa.verify(prestr, sign)

    def sign(self, data):
        """ 签名
        :param data: 需要签名的内容
        :type data: dict
        :return: 签名结果
        :rtype: str
        """
        prestr = self.get_sign_str(data)

        return self.rsa.sign(prestr)

    @staticmethod
    def get_sign_str(data):
        # 除去待签名参数数组中的空值和签名参数
        para_filter = core.para_filter(data)

        # 对待签名参数数组排序
        para_sort = core.arg_sort(para_filter)

        # 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
        return core.create_link_string(para_sort)