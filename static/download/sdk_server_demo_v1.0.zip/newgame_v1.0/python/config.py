#!-*- coding:utf-8 -*-

import os

BASE_PATH = os.path.dirname(os.path.abspath(__file__))

# 全局变量

# public_key为新游的公钥
PUBLIC_KEY = os.path.join(BASE_PATH, 'keys', 'newgame_public_key.pem')

# private_key为开发者自己的私钥，需要使用openssl生成
PRIVATE_KEY = os.path.join(BASE_PATH, 'keys', 'rsa_private_key.pem')

TIMEOUT = 10  # 超时时间

SIGN_TYPE = "RSA" # 签名方式，不需要修改