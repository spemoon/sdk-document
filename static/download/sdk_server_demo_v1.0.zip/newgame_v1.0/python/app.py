# -*- coding: utf-8 -*-

from flask import Flask, request
from libs import Notify
import config

app = Flask(__name__)
new_game = Notify(config)


@app.route('/notify', methods=['POST'])
def notify():
    """ 通知测试页面
    """

    # 获取新游的通知返回参数，可参考技术文档中页面跳转同步通知参数列表(以下仅供参考)
    # 商户订单号
    app_order_id = request.form.get("app_order_id")

    # 新游交易号
    order_id = request.form.get("order_id")

    #交易状态
    status = request.form.get("status")

    #获取新游的通知返回参数，可参考技术文档中页面跳转同步通知参数列表(以上仅供参考)
    if new_game.verify_return(request.form):
        # 支付成功
        # 请在这里加上商户的业务逻辑程序代码

        # ——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
        if status == 'STATUS_SUCCESS':
            # 判断该笔订单是否在商户网站中已经做过处理
            # 如果没有做过处理，根据订单号（app_order_id）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
            # 如果有做过处理，不执行商户的业务程序
            pass

        # ——请根据您的业务逻辑来编写程序（以上代码仅作参考）——
        return 'success'  # 请不要修改或删除
    else:
        return 'fail'


if __name__ == '__main__':
    app.run(debug=True)