
            ╭───────────────────────╮
    ────┤           新游代码示例结构说明             ├────
            ╰───────────────────────╯ 

　 　    代码版本：1.0
         开发语言：PHP

    ─────────────────────────────────

───────
 代码文件结构
───────

PHP
  │
  ├libs┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈类文件夹
  │  │
  │  ├core.py ┈┈┈┈┈┈新游接口公用函数文件
  │  │
  │  ├notify.py┈┈┈┈┈┈┈新游通知处理类文件
  │  │
  │  └crypt.py┈┈┈┈┈┈┈新游接口RSA函数文件
  │
  ├log.txt┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈日志文件
  │
  ├config.py┈┈┈┈┈┈┈┈┈┈┈┈基础配置类文件
  │
  ├app.py ┈┈┈┈┈┈┈┈┈┈┈┈┈服务器异步通知页面文件
  │
  ├keys┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈私钥公钥文件夹（用法见下方※注意※）
  │  │
  │  ├rsa_private_key.pem┈┈┈┈┈┈┈┈┈商户的私钥文件
  │  │
  │  └newgame_public_key.pem┈┈┈┈┈┈┈┈新游的公钥文件
  │
  │
  └readme.txt ┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈使用说明文本

※注意※

1、需要配置的文件是：
config.py
app.py
keys文件夹


3、秘钥解答：
●商户的私钥、商户的公钥、新游公钥

key文件夹里面须存放.pem后缀名的商户私钥、新游的公钥两个文件。

◆商户的私钥
1、必须保证只有一行文字，即，没有回车、换行、空格等
2、不需要对刚生成的（原始的）私钥做pkcs8编码
3、不需要去掉去掉“-----BEGIN PUBLIC KEY-----”、“-----END PUBLIC KEY-----”
简言之，只要维持刚生成出来的私钥的内容即可。

◆商户的公钥
1、必须保证只有一行文字，即，没有回车、换行、空格等
2、去掉“-----BEGIN PUBLIC KEY-----”、“-----END PUBLIC KEY-----”，只保存这两条文字之中的部分
3、保存好后，在开发者平台提交给新游。

◆新游公钥
1、必须保证只有一行文字，即，没有回车、换行、空格等
2、须保留“-----BEGIN PUBLIC KEY-----”、“-----END PUBLIC KEY-----”这两条文字。
简言之，新游公钥只需要维持原样即可。

─────────
 类文件函数结构
─────────

core.py

function create_link_string(params)
功能：把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
输入：dict  params 需要拼接的数组
输出：str 拼接完成以后的字符串

function create_link_string_urlencode(params)
功能：把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串，并对参数值urlencode
输入：dict  params 需要拼接的数组
输出：str 拼接完成以后的字符串

function para_filter(params)
功能：除去数组中的空值和签名参数
输入：dict  params 签名参数组
输出：dict  去掉空值与签名参数后的新签名参数组

function argSort(params)
功能：对数组排序
输入：dict  params 排序前的数组
输出：OrderedDict  排序后的数组


┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉

crypt.py

function sign(sign_data, private_key)
功能：RSA签名
输入：str data 待签名数据
      str private_key 商户私钥文件路径或内容
输出：str 签名结果

function verify(data, sign, public_key_path)
功能：RSA验签
输入：str data 待签名数据
      str public_key_path 新游的公钥文件路径或内容
      str sign 要校对的的签名结果
输出：bool 验证结果

function rsa_base64_decrypt(data, private_key)
功能：RSA解密
输入：str data需要解密的内容，密文
      str private_key 商户私钥文件路径
输出：str 解密后内容，明文

┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉


notify.class.php

function verify_return(result)
功能：对return_url的认证
输入： dict result 请求参数
输出：bool  验证结果：true/false

function get_sign_verify(para_temp, sign)
功能：获取返回时的签名验证结果
输入：dict para_temp 通知返回来的参数数组
      str sign 新游返回的签名结果
输出：bool 获得签名验证结果
